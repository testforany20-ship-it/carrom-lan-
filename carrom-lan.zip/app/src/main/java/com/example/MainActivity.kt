package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.GameScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LanLobbyScreen
import com.example.ui.theme.CarromTheme
import com.example.viewmodel.CarromViewModel
import com.example.viewmodel.UiNavEvent

object CarromRoutes {
    const val HOME = "home"
    const val LAN_LOBBY = "lan_lobby"
    const val GAME = "game"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CarromTheme {
                val vm: CarromViewModel = viewModel()
                val navController = rememberNavController()
                val haptics = LocalHapticFeedback.current

                val preferences by vm.preferences.collectAsStateWithLifecycle()
                val matchState by vm.matchState.collectAsStateWithLifecycle()
                val localAim by vm.localAim.collectAsStateWithLifecycle()
                val lobbyState by vm.lobbyState.collectAsStateWithLifecycle()
                val floatingEmote by vm.floatingEmote.collectAsStateWithLifecycle()

                LaunchedEffect(Unit) {
                    vm.navEvents.collect { event ->
                        when (event) {
                            UiNavEvent.NavigateToGame -> {
                                navController.navigate(CarromRoutes.GAME) {
                                    launchSingleTop = true
                                }
                            }
                            UiNavEvent.NavigateToHome -> {
                                navController.popBackStack(CarromRoutes.HOME, inclusive = false)
                            }
                        }
                    }
                }

                LaunchedEffect(Unit) {
                    vm.hapticTrigger.collect { intensity ->
                        if (intensity > 0.4f) {
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        } else {
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = CarromRoutes.HOME
                ) {
                    composable(CarromRoutes.HOME) {
                        HomeScreen(
                            preferences = preferences,
                            onHostLanClick = {
                                vm.startHostingRoom()
                                navController.navigate(CarromRoutes.LAN_LOBBY)
                            },
                            onJoinLanClick = {
                                vm.startScanningRooms()
                                navController.navigate(CarromRoutes.LAN_LOBBY)
                            },
                            onStartOfflineMatch = { matchType, mode ->
                                vm.startOfflineMatch(matchType, mode)
                            },
                            onUpdateName = vm::updatePlayerName,
                            onToggleSound = vm::toggleSound,
                            onToggleHaptics = vm::toggleHaptics,
                            onSelectBoardTheme = vm::selectBoardTheme,
                            onSelectStrikerStyle = vm::selectStrikerStyle
                        )
                    }

                    composable(CarromRoutes.LAN_LOBBY) {
                        LanLobbyScreen(
                            lobbyState = lobbyState,
                            localPlayerName = preferences.playerName,
                            onSwitchToHost = { vm.startHostingRoom() },
                            onSwitchToJoin = { vm.startScanningRooms() },
                            onRefreshNetwork = vm::refreshNetworkInfo,
                            onSelectMode = vm::changeHostMode,
                            onJoinRoom = vm::joinRoomByObject,
                            onJoinByIp = { ip -> vm.joinRoomByIp(ip) },
                            onToggleReady = vm::toggleGuestReady,
                            onStartMatch = vm::startLanMatchAsHost,
                            onSendChat = vm::sendLobbyChat,
                            onBack = {
                                vm.leaveLobbyOrMatch()
                                navController.popBackStack(CarromRoutes.HOME, inclusive = false)
                            }
                        )
                    }

                    composable(CarromRoutes.GAME) {
                        GameScreen(
                            matchState = matchState,
                            localAim = localAim,
                            preferences = preferences,
                            pingMs = lobbyState.pingMs,
                            floatingEmote = floatingEmote,
                            isBoardRotated = vm.isBoardRotatedForLocalViewer(),
                            canInteract = vm.canLocalUserControlTurn(),
                            onSliderChanged = vm::onStrikerSliderChanged,
                            onAimUpdate = vm::onAimDrag,
                            onShoot = vm::releaseShot,
                            onToggleSound = vm::toggleSound,
                            onSendEmote = vm::sendInGameEmote,
                            onRematch = vm::requestRematch,
                            onExitMatch = {
                                vm.leaveLobbyOrMatch()
                                navController.popBackStack(CarromRoutes.HOME, inclusive = false)
                            }
                        )
                    }
                }
            }
        }
    }
}
