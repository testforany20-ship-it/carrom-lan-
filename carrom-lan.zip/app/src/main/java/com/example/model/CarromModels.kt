package com.example.model

enum class GameMode(
    val title: String,
    val subtitle: String,
    val badge: String
) {
    CLASSIC_QUEEN(
        title = "Classic Queen",
        subtitle = "Pot your 9 coins + cover the Red Queen",
        badge = "Official"
    ),
    DISC_POOL(
        title = "Disc Pool",
        subtitle = "Fast race to sink all 9 of your color discs",
        badge = "Fast"
    ),
    POINTS_29(
        title = "Points Blitz",
        subtitle = "White 2pt, Black 1pt, Queen 5pt — high score wins",
        badge = "Arcade"
    )
}

enum class MatchType {
    VS_AI,
    PASS_AND_PLAY,
    LAN_HOST,
    LAN_CLIENT
}

enum class DiscType {
    WHITE,
    BLACK,
    QUEEN,
    STRIKER
}

enum class PlayerSeat {
    PLAYER_1, // Host / Bottom in canonical coordinates
    PLAYER_2  // Guest / Top in canonical coordinates
}

enum class QueenState {
    ON_BOARD,
    NEEDS_COVER_P1,
    NEEDS_COVER_P2,
    COVERED_P1,
    COVERED_P2
}

enum class TurnPhase {
    AIMING,
    SIMULATING,
    MATCH_OVER
}

enum class BoardTheme(
    val displayName: String,
    val surfaceLightHex: Long,
    val surfaceMidHex: Long,
    val frameOuterHex: Long,
    val frameInnerHex: Long,
    val lineColorHex: Long,
    val accentColorHex: Long
) {
    ROYAL_MAPLE(
        displayName = "Royal Maple",
        surfaceLightHex = 0xFFF6E3C3,
        surfaceMidHex = 0xFFE9CBA0,
        frameOuterHex = 0xFF452416,
        frameInnerHex = 0xFF28130B,
        lineColorHex = 0xFF3A2216,
        accentColorHex = 0xFFC62828
    ),
    EMERALD_CLUB(
        displayName = "Emerald Club",
        surfaceLightHex = 0xFFDFEFE4,
        surfaceMidHex = 0xFFC2DCCB,
        frameOuterHex = 0xFF1D382B,
        frameInnerHex = 0xFF0F2018,
        lineColorHex = 0xFF1A3A2B,
        accentColorHex = 0xFFD93829
    ),
    MIDNIGHT_SLATE(
        displayName = "Midnight Slate",
        surfaceLightHex = 0xFF2C3340,
        surfaceMidHex = 0xFF212733,
        frameOuterHex = 0xFF151821,
        frameInnerHex = 0xFF0D0F15,
        lineColorHex = 0xFF8DA2BF,
        accentColorHex = 0xFFF2B705
    )
}

enum class StrikerStyle(
    val displayName: String,
    val coreHex: Long,
    val ringHex: Long,
    val innerHex: Long
) {
    IVORY_GOLD(
        displayName = "Ivory Gold",
        coreHex = 0xFFFFFBF0,
        ringHex = 0xFFF2B705,
        innerHex = 0xFFD99B26
    ),
    CRIMSON_VIPER(
        displayName = "Crimson Viper",
        coreHex = 0xFF241616,
        ringHex = 0xFFD93829,
        innerHex = 0xFFFF6B57
    ),
    CYAN_PULSE(
        displayName = "Arctic Pulse",
        coreHex = 0xFF0F222D,
        ringHex = 0xFF38BDF8,
        innerHex = 0xFF7DD3FC
    ),
    OBSIDIAN_CROWN(
        displayName = "Obsidian Crown",
        coreHex = 0xFF171412,
        ringHex = 0xFFE5C158,
        innerHex = 0xFF8B6914
    )
}

data class DiscState(
    val id: Int,
    val type: DiscType,
    val x: Float,
    val y: Float,
    val vx: Float = 0f,
    val vy: Float = 0f,
    val pocketed: Boolean = false,
    val sinkProgress: Float = 0f,
    val pocketX: Float = 0f,
    val pocketY: Float = 0f
)

data class AimState(
    val isAiming: Boolean = false,
    val pullDx: Float = 0f,
    val pullDy: Float = 0f
)

data class MatchState(
    val mode: GameMode = GameMode.CLASSIC_QUEEN,
    val matchType: MatchType = MatchType.VS_AI,
    val player1Name: String = "You",
    val player2Name: String = "Bot",
    val currentTurn: PlayerSeat = PlayerSeat.PLAYER_1,
    val phase: TurnPhase = TurnPhase.AIMING,
    val discs: List<DiscState> = emptyList(),
    val striker: DiscState = DiscState(id = 99, type = DiscType.STRIKER, x = 500f, y = 835f),
    val queenState: QueenState = QueenState.ON_BOARD,
    val p1Score: Int = 0,
    val p2Score: Int = 0,
    val p1PocketedCount: Int = 0,
    val p2PocketedCount: Int = 0,
    val statusBanner: String = "Break shot! Drag striker & pull back to aim",
    val winner: PlayerSeat? = null,
    val winReason: String = "",
    val turnNumber: Int = 1,
    val strikerPlacementValid: Boolean = true,
    val opponentAim: AimState = AimState()
)

data class DiscoveredRoom(
    val roomId: String,
    val hostName: String,
    val hostIp: String,
    val port: Int,
    val mode: GameMode,
    val playerCount: Int,
    val lastSeenMs: Long
)

data class LobbyChatMessage(
    val id: String,
    val sender: String,
    val text: String,
    val timestampMs: Long,
    val isSystem: Boolean = false
)

enum class LanConnectionRole {
    NONE,
    HOSTING,
    JOINING,
    CONNECTED_AS_HOST,
    CONNECTED_AS_CLIENT
}

data class LanLobbyState(
    val role: LanConnectionRole = LanConnectionRole.NONE,
    val localIps: List<String> = emptyList(),
    val suggestedHostIp: String = "192.168.43.1",
    val hostName: String = "",
    val guestName: String? = null,
    val guestReady: Boolean = false,
    val selectedMode: GameMode = GameMode.CLASSIC_QUEEN,
    val isScanning: Boolean = false,
    val discoveredRooms: List<DiscoveredRoom> = emptyList(),
    val chatMessages: List<LobbyChatMessage> = emptyList(),
    val pingMs: Int = 0,
    val errorMessage: String? = null,
    val connectedHostIp: String = ""
)

data class UserPreferences(
    val playerName: String = "Striker",
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val boardTheme: BoardTheme = BoardTheme.ROYAL_MAPLE,
    val strikerStyle: StrikerStyle = StrikerStyle.IVORY_GOLD,
    val matchesPlayed: Int = 0,
    val wins: Int = 0
)
