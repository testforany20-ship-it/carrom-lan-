package com.example.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import com.example.model.AimState
import com.example.model.DiscState
import com.example.model.DiscType
import com.example.model.DiscoveredRoom
import com.example.model.GameMode
import com.example.model.MatchState
import com.example.model.PlayerSeat
import com.example.model.QueenState
import com.example.model.TurnPhase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

sealed class LanPacketEvent {
    data class ClientConnected(val guestName: String) : LanPacketEvent()
    data class JoinAccepted(val hostName: String, val mode: GameMode, val hostIp: String) : LanPacketEvent()
    data class JoinRejected(val reason: String) : LanPacketEvent()
    data class LobbyUpdated(
        val hostName: String,
        val guestName: String?,
        val guestReady: Boolean,
        val mode: GameMode,
        val matchStarted: Boolean
    ) : LanPacketEvent()
    data class GuestReadyChanged(val ready: Boolean) : LanPacketEvent()
    data class ChatReceived(val sender: String, val text: String) : LanPacketEvent()
    data class StrikerSlide(val x: Float) : LanPacketEvent()
    data class AimPreview(val aim: AimState) : LanPacketEvent()
    data class ShotCommand(val strikerX: Float, val vx: Float, val vy: Float) : LanPacketEvent()
    data class SnapshotReceived(val snapshot: MatchState) : LanPacketEvent()
    data class RematchRequested(val fromName: String) : LanPacketEvent()
    data class PingUpdated(val pingMs: Int) : LanPacketEvent()
    data class Disconnected(val reason: String) : LanPacketEvent()
}

class LanMultiplayerManager(private val context: Context) {

    companion object {
        const val DEFAULT_TCP_PORT = 45454
        const val DISCOVERY_UDP_PORT = 45455
        const val NSD_SERVICE_TYPE = "_carromlan._tcp."
        private const val BEACON_MAGIC = "CARROM_LAN_BEACON_V1"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    private val connectivityManager = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    private val nsdManager = context.applicationContext.getSystemService(Context.NSD_SERVICE) as? NsdManager

    private var multicastLock: WifiManager.MulticastLock? = null

    private val _events = MutableSharedFlow<LanPacketEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<LanPacketEvent> = _events.asSharedFlow()

    private val _discoveredRooms = MutableStateFlow<List<DiscoveredRoom>>(emptyList())
    val discoveredRooms: StateFlow<List<DiscoveredRoom>> = _discoveredRooms.asStateFlow()

    private val roomsMap = ConcurrentHashMap<String, DiscoveredRoom>()

    private var serverSocket: ServerSocket? = null
    private var activeSocket: Socket? = null
    private var writer: PrintWriter? = null
    private val writeLock = Any()

    private var hostJob: Job? = null
    private var beaconJob: Job? = null
    private var discoveryJob: Job? = null
    private var readerJob: Job? = null
    private var pingJob: Job? = null

    private var nsdRegistrationListener: NsdManager.RegistrationListener? = null
    private var nsdDiscoveryListener: NsdManager.DiscoveryListener? = null

    @Volatile
    private var currentHostRoomId: String = UUID.randomUUID().toString().take(8)
    @Volatile
    private var currentHostName: String = "Host"
    @Volatile
    private var currentHostMode: GameMode = GameMode.CLASSIC_QUEEN
    @Volatile
    private var currentPlayerCount: Int = 1
    @Volatile
    private var currentTcpPort: Int = DEFAULT_TCP_PORT

    fun getLocalIpAddresses(): List<String> {
        val result = mutableListOf<String>()
        runCatching {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return@runCatching
            while (interfaces.hasMoreElements()) {
                val nif = interfaces.nextElement()
                if (!nif.isUp || nif.isLoopback) continue
                val addrs = nif.inetAddresses
                while (addrs.hasMoreElements()) {
                    val addr = addrs.nextElement()
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val ip = addr.hostAddress ?: continue
                        // Prioritize hotspot/wlan private IPs first
                        if (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.")) {
                            if (nif.name.contains("ap", ignoreCase = true) || nif.name.contains("wlan", ignoreCase = true)) {
                                result.add(0, ip)
                            } else {
                                result.add(ip)
                            }
                        }
                    }
                }
            }
        }
        return result.distinct()
    }

    fun getSuggestedHostIp(): String {
        runCatching {
            val activeNet = connectivityManager?.activeNetwork
            val caps = activeNet?.let { connectivityManager?.getNetworkCapabilities(it) }
            if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                val linkProps = connectivityManager?.getLinkProperties(activeNet)
                val gateway = linkProps?.routes
                    ?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
                    ?.gateway?.hostAddress
                if (!gateway.isNullOrBlank() && gateway != "0.0.0.0") {
                    return gateway
                }
            }
        }
        return "192.168.43.1"
    }

    fun startHosting(hostName: String, mode: GameMode) {
        stopAll()
        currentHostRoomId = UUID.randomUUID().toString().take(8)
        currentHostName = hostName
        currentHostMode = mode
        currentPlayerCount = 1
        acquireMulticastLock()

        hostJob = scope.launch {
            try {
                val ss = try {
                    ServerSocket().apply {
                        reuseAddress = true
                        bind(InetSocketAddress(DEFAULT_TCP_PORT))
                    }
                } catch (_: Exception) {
                    ServerSocket(0)
                }
                serverSocket = ss
                currentTcpPort = ss.localPort

                startBeaconBroadcaster()
                registerNsdService(hostName, currentTcpPort)

                while (isActive && !ss.isClosed) {
                    val client = ss.accept()
                    if (activeSocket != null && activeSocket?.isClosed == false) {
                        // Room already has 2 players
                        runCatching {
                            val pw = PrintWriter(client.getOutputStream(), true)
                            pw.println(JSONObject().apply {
                                put("type", "join_reject")
                                put("reason", "Room is full (2/2 players)")
                            }.toString())
                            client.close()
                        }
                        continue
                    }

                    setupTcpConnection(client, isHost = true, expectedLocalName = hostName)
                }
            } catch (e: Exception) {
                if (isActive) {
                    _events.tryEmit(LanPacketEvent.Disconnected("Host error: ${e.message ?: "socket closed"}"))
                }
            }
        }
    }

    fun updateHostBeaconState(mode: GameMode, playerCount: Int) {
        currentHostMode = mode
        currentPlayerCount = playerCount
    }

    fun startDiscovery() {
        stopDiscovery()
        roomsMap.clear()
        _discoveredRooms.value = emptyList()
        acquireMulticastLock()

        discoveryJob = scope.launch {
            var udpSocket: DatagramSocket? = null
            try {
                udpSocket = DatagramSocket(null).apply {
                    reuseAddress = true
                    soTimeout = 1000
                    bind(InetSocketAddress(DISCOVERY_UDP_PORT))
                }
                val buffer = ByteArray(2048)
                while (isActive) {
                    try {
                        val packet = DatagramPacket(buffer, buffer.size)
                        udpSocket.receive(packet)
                        val raw = String(packet.data, 0, packet.length, Charsets.UTF_8)
                        val json = JSONObject(raw)
                        if (json.optString("magic") == BEACON_MAGIC) {
                            val roomId = json.optString("roomId")
                            val hostIp = packet.address.hostAddress ?: continue
                            // Ignore self-beacons if somehow echoed
                            if (hostIp in getLocalIpAddresses() && roomId == currentHostRoomId) continue
                            val mode = runCatching {
                                GameMode.valueOf(json.optString("mode"))
                            }.getOrDefault(GameMode.CLASSIC_QUEEN)
                            val room = DiscoveredRoom(
                                roomId = roomId,
                                hostName = json.optString("hostName", "Player"),
                                hostIp = hostIp,
                                port = json.optInt("port", DEFAULT_TCP_PORT),
                                mode = mode,
                                playerCount = json.optInt("players", 1),
                                lastSeenMs = System.currentTimeMillis()
                            )
                            roomsMap[room.roomId] = room
                        }
                    } catch (_: Exception) {
                        // Socket timeout every 1s lets us prune stale rooms cleanly
                    }
                    pruneAndPublishRooms()
                }
            } catch (_: Exception) {
                // Even if UDP port bind fails on a device, NSD + Direct IP Connect still work
            } finally {
                runCatching { udpSocket?.close() }
            }
        }

        startNsdDiscovery()
    }

    fun stopDiscovery() {
        discoveryJob?.cancel()
        discoveryJob = null
        stopNsdDiscovery()
        roomsMap.clear()
        _discoveredRooms.value = emptyList()
    }

    fun joinRoom(hostIp: String, port: Int = DEFAULT_TCP_PORT, guestName: String) {
        stopDiscovery()
        closeActiveSocketOnly()

        scope.launch {
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(hostIp.trim(), port), 4500)
                setupTcpConnection(socket, isHost = false, expectedLocalName = guestName)
                sendJson(JSONObject().apply {
                    put("type", "join_req")
                    put("guestName", guestName)
                })
            } catch (e: Exception) {
                _events.tryEmit(
                    LanPacketEvent.JoinRejected(
                        "Could not connect to $hostIp:$port. Check Hotspot/Wi-Fi and Host IP."
                    )
                )
            }
        }
    }

    private fun setupTcpConnection(socket: Socket, isHost: Boolean, expectedLocalName: String) {
        socket.tcpNoDelay = true
        socket.soTimeout = 0
        activeSocket = socket
        writer = PrintWriter(socket.getOutputStream(), true)

        readerJob?.cancel()
        readerJob = scope.launch {
            try {
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                while (isActive && !socket.isClosed) {
                    val line = reader.readLine() ?: break
                    handleIncomingJson(line, isHost, socket.inetAddress?.hostAddress ?: "")
                }
            } catch (_: Exception) {
            } finally {
                if (isActive) {
                    _events.tryEmit(LanPacketEvent.Disconnected("Connection closed by peer"))
                }
            }
        }

        startPingLoop()
        if (!isHost) {
            // Client awaits join_ack from host
        } else {
            // Host waits for join_req
            currentPlayerCount = 2
        }
    }

    private fun startPingLoop() {
        pingJob?.cancel()
        pingJob = scope.launch {
            while (isActive && activeSocket?.isClosed == false) {
                sendJson(JSONObject().apply {
                    put("type", "ping")
                    put("ts", System.currentTimeMillis())
                })
                delay(2500)
            }
        }
    }

    private fun handleIncomingJson(raw: String, isHost: Boolean, remoteIp: String) {
        val json = runCatching { JSONObject(raw) }.getOrNull() ?: return
        when (json.optString("type")) {
            "ping" -> {
                sendJson(JSONObject().apply {
                    put("type", "pong")
                    put("ts", json.optLong("ts"))
                })
            }
            "pong" -> {
                val sent = json.optLong("ts")
                val rtt = (System.currentTimeMillis() - sent).coerceIn(1L, 999L).toInt()
                _events.tryEmit(LanPacketEvent.PingUpdated(rtt))
            }
            "join_req" -> {
                if (isHost) {
                    val guestName = json.optString("guestName", "Friend")
                    sendJson(JSONObject().apply {
                        put("type", "join_ack")
                        put("hostName", currentHostName)
                        put("mode", currentHostMode.name)
                    })
                    _events.tryEmit(LanPacketEvent.ClientConnected(guestName))
                }
            }
            "join_ack" -> {
                val hostName = json.optString("hostName", "Host")
                val mode = runCatching { GameMode.valueOf(json.optString("mode")) }
                    .getOrDefault(GameMode.CLASSIC_QUEEN)
                _events.tryEmit(LanPacketEvent.JoinAccepted(hostName, mode, remoteIp))
            }
            "join_reject" -> {
                _events.tryEmit(LanPacketEvent.JoinRejected(json.optString("reason", "Rejected by host")))
                closeActiveSocketOnly()
            }
            "lobby_state" -> {
                val mode = runCatching { GameMode.valueOf(json.optString("mode")) }
                    .getOrDefault(GameMode.CLASSIC_QUEEN)
                _events.tryEmit(
                    LanPacketEvent.LobbyUpdated(
                        hostName = json.optString("hostName", "Host"),
                        guestName = json.optString("guestName").takeIf { it.isNotBlank() },
                        guestReady = json.optBoolean("guestReady", false),
                        mode = mode,
                        matchStarted = json.optBoolean("started", false)
                    )
                )
            }
            "ready_toggle" -> {
                _events.tryEmit(LanPacketEvent.GuestReadyChanged(json.optBoolean("ready", false)))
            }
            "chat" -> {
                _events.tryEmit(
                    LanPacketEvent.ChatReceived(
                        sender = json.optString("sender", "Player"),
                        text = json.optString("text", "")
                    )
                )
            }
            "striker_slide" -> {
                _events.tryEmit(LanPacketEvent.StrikerSlide(json.optDouble("x", 500.0).toFloat()))
            }
            "aim_preview" -> {
                _events.tryEmit(
                    LanPacketEvent.AimPreview(
                        AimState(
                            isAiming = json.optBoolean("aiming", false),
                            pullDx = json.optDouble("dx", 0.0).toFloat(),
                            pullDy = json.optDouble("dy", 0.0).toFloat()
                        )
                    )
                )
            }
            "shot_cmd" -> {
                _events.tryEmit(
                    LanPacketEvent.ShotCommand(
                        strikerX = json.optDouble("sx", 500.0).toFloat(),
                        vx = json.optDouble("vx", 0.0).toFloat(),
                        vy = json.optDouble("vy", 0.0).toFloat()
                    )
                )
            }
            "snapshot" -> {
                decodeMatchSnapshot(json)?.let {
                    _events.tryEmit(LanPacketEvent.SnapshotReceived(it))
                }
            }
            "rematch" -> {
                _events.tryEmit(LanPacketEvent.RematchRequested(json.optString("from", "Friend")))
            }
            "leave" -> {
                _events.tryEmit(LanPacketEvent.Disconnected("Opponent left the room"))
            }
        }
    }

    fun sendLobbyState(
        hostName: String,
        guestName: String?,
        guestReady: Boolean,
        mode: GameMode,
        started: Boolean
    ) {
        currentHostMode = mode
        sendJson(JSONObject().apply {
            put("type", "lobby_state")
            put("hostName", hostName)
            put("guestName", guestName ?: "")
            put("guestReady", guestReady)
            put("mode", mode.name)
            put("started", started)
        })
    }

    fun sendGuestReady(ready: Boolean) {
        sendJson(JSONObject().apply {
            put("type", "ready_toggle")
            put("ready", ready)
        })
    }

    fun sendChat(sender: String, text: String) {
        sendJson(JSONObject().apply {
            put("type", "chat")
            put("sender", sender)
            put("text", text)
        })
    }

    fun sendStrikerSlide(x: Float) {
        sendJson(JSONObject().apply {
            put("type", "striker_slide")
            put("x", x.toDouble())
        })
    }

    fun sendAimPreview(aim: AimState) {
        sendJson(JSONObject().apply {
            put("type", "aim_preview")
            put("aiming", aim.isAiming)
            put("dx", aim.pullDx.toDouble())
            put("dy", aim.pullDy.toDouble())
        })
    }

    fun sendShotCommand(strikerX: Float, vx: Float, vy: Float) {
        sendJson(JSONObject().apply {
            put("type", "shot_cmd")
            put("sx", strikerX.toDouble())
            put("vx", vx.toDouble())
            put("vy", vy.toDouble())
        })
    }

    fun sendGameSnapshot(state: MatchState) {
        val discsJson = JSONArray()
        for (d in state.discs) {
            discsJson.put(JSONObject().apply {
                put("i", d.id)
                put("t", d.type.name)
                put("x", d.x.toDouble())
                put("y", d.y.toDouble())
                put("vx", d.vx.toDouble())
                put("vy", d.vy.toDouble())
                put("p", d.pocketed)
                put("sp", d.sinkProgress.toDouble())
                put("px", d.pocketX.toDouble())
                put("py", d.pocketY.toDouble())
            })
        }
        val s = state.striker
        val strikerJson = JSONObject().apply {
            put("x", s.x.toDouble())
            put("y", s.y.toDouble())
            put("vx", s.vx.toDouble())
            put("vy", s.vy.toDouble())
            put("p", s.pocketed)
            put("sp", s.sinkProgress.toDouble())
            put("px", s.pocketX.toDouble())
            put("py", s.pocketY.toDouble())
        }
        sendJson(JSONObject().apply {
            put("type", "snapshot")
            put("mode", state.mode.name)
            put("p1", state.player1Name)
            put("p2", state.player2Name)
            put("turn", state.currentTurn.name)
            put("phase", state.phase.name)
            put("q", state.queenState.name)
            put("s1", state.p1Score)
            put("s2", state.p2Score)
            put("c1", state.p1PocketedCount)
            put("c2", state.p2PocketedCount)
            put("banner", state.statusBanner)
            put("winner", state.winner?.name ?: "")
            put("winReason", state.winReason)
            put("tn", state.turnNumber)
            put("valid", state.strikerPlacementValid)
            put("discs", discsJson)
            put("striker", strikerJson)
        })
    }

    fun sendRematchRequest(fromName: String) {
        sendJson(JSONObject().apply {
            put("type", "rematch")
            put("from", fromName)
        })
    }

    fun sendLeave() {
        sendJson(JSONObject().apply {
            put("type", "leave")
        })
    }

    private fun decodeMatchSnapshot(json: JSONObject): MatchState? {
        return runCatching {
            val mode = GameMode.valueOf(json.optString("mode", GameMode.CLASSIC_QUEEN.name))
            val turn = PlayerSeat.valueOf(json.optString("turn", PlayerSeat.PLAYER_1.name))
            val phase = TurnPhase.valueOf(json.optString("phase", TurnPhase.AIMING.name))
            val queenState = QueenState.valueOf(json.optString("q", QueenState.ON_BOARD.name))
            val winnerStr = json.optString("winner")
            val winner = if (winnerStr.isBlank()) null else PlayerSeat.valueOf(winnerStr)

            val discsArr = json.getJSONArray("discs")
            val discs = ArrayList<DiscState>(discsArr.length())
            for (idx in 0 until discsArr.length()) {
                val obj = discsArr.getJSONObject(idx)
                discs += DiscState(
                    id = obj.getInt("i"),
                    type = DiscType.valueOf(obj.getString("t")),
                    x = obj.getDouble("x").toFloat(),
                    y = obj.getDouble("y").toFloat(),
                    vx = obj.optDouble("vx", 0.0).toFloat(),
                    vy = obj.optDouble("vy", 0.0).toFloat(),
                    pocketed = obj.optBoolean("p", false),
                    sinkProgress = obj.optDouble("sp", 0.0).toFloat(),
                    pocketX = obj.optDouble("px", 0.0).toFloat(),
                    pocketY = obj.optDouble("py", 0.0).toFloat()
                )
            }

            val sj = json.getJSONObject("striker")
            val striker = DiscState(
                id = 99,
                type = DiscType.STRIKER,
                x = sj.getDouble("x").toFloat(),
                y = sj.getDouble("y").toFloat(),
                vx = sj.optDouble("vx", 0.0).toFloat(),
                vy = sj.optDouble("vy", 0.0).toFloat(),
                pocketed = sj.optBoolean("p", false),
                sinkProgress = sj.optDouble("sp", 0.0).toFloat(),
                pocketX = sj.optDouble("px", 0.0).toFloat(),
                pocketY = sj.optDouble("py", 0.0).toFloat()
            )

            MatchState(
                mode = mode,
                matchType = com.example.model.MatchType.LAN_CLIENT,
                player1Name = json.optString("p1", "Host"),
                player2Name = json.optString("p2", "You"),
                currentTurn = turn,
                phase = phase,
                discs = discs,
                striker = striker,
                queenState = queenState,
                p1Score = json.optInt("s1", 0),
                p2Score = json.optInt("s2", 0),
                p1PocketedCount = json.optInt("c1", 0),
                p2PocketedCount = json.optInt("c2", 0),
                statusBanner = json.optString("banner", ""),
                winner = winner,
                winReason = json.optString("winReason", ""),
                turnNumber = json.optInt("tn", 1),
                strikerPlacementValid = json.optBoolean("valid", true)
            )
        }.getOrNull()
    }

    private fun sendJson(json: JSONObject) {
        val payload = json.toString()
        scope.launch {
            synchronized(writeLock) {
                runCatching {
                    writer?.println(payload)
                    writer?.flush()
                }
            }
        }
    }

    private fun startBeaconBroadcaster() {
        beaconJob?.cancel()
        beaconJob = scope.launch {
            var socket: DatagramSocket? = null
            try {
                socket = DatagramSocket().apply { broadcast = true }
                while (isActive) {
                    val msg = JSONObject().apply {
                        put("magic", BEACON_MAGIC)
                        put("roomId", currentHostRoomId)
                        put("hostName", currentHostName)
                        put("port", currentTcpPort)
                        put("mode", currentHostMode.name)
                        put("players", currentPlayerCount)
                    }.toString().toByteArray(Charsets.UTF_8)

                    val targets = collectBroadcastAddresses()
                    for (addr in targets) {
                        runCatching {
                            val packet = DatagramPacket(msg, msg.size, addr, DISCOVERY_UDP_PORT)
                            socket.send(packet)
                        }
                    }
                    delay(700)
                }
            } catch (_: Exception) {
            } finally {
                runCatching { socket?.close() }
            }
        }
    }

    private fun collectBroadcastAddresses(): List<InetAddress> {
        val addresses = linkedSetOf<InetAddress>()
        runCatching {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return@runCatching
            while (interfaces.hasMoreElements()) {
                val nif = interfaces.nextElement()
                if (!nif.isUp || nif.isLoopback) continue
                for (ifa in nif.interfaceAddresses) {
                    val bcast = ifa.broadcast
                    if (bcast != null) {
                        addresses += bcast
                    }
                }
            }
        }
        runCatching {
            addresses += InetAddress.getByName("255.255.255.255")
        }
        return addresses.toList()
    }

    private fun pruneAndPublishRooms() {
        val now = System.currentTimeMillis()
        val iterator = roomsMap.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (now - entry.value.lastSeenMs > 4500L) {
                iterator.remove()
            }
        }
        _discoveredRooms.value = roomsMap.values.sortedByDescending { it.lastSeenMs }
    }

    private fun registerNsdService(hostName: String, port: Int) {
        unregisterNsdService()
        val manager = nsdManager ?: return
        val info = NsdServiceInfo().apply {
            serviceName = "CarromLAN_${hostName.take(10)}_$currentHostRoomId"
            serviceType = NSD_SERVICE_TYPE
            this.port = port
        }
        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) {}
            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
            override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) {}
            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
        }
        nsdRegistrationListener = listener
        runCatching {
            manager.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener)
        }
    }

    private fun unregisterNsdService() {
        val manager = nsdManager ?: return
        val listener = nsdRegistrationListener ?: return
        nsdRegistrationListener = null
        runCatching { manager.unregisterService(listener) }
    }

    private fun startNsdDiscovery() {
        stopNsdDiscovery()
        val manager = nsdManager ?: return
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(regType: String) {}
            override fun onServiceFound(service: NsdServiceInfo) {
                if (service.serviceType != NSD_SERVICE_TYPE) return
                runCatching {
                    manager.resolveService(service, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
                        override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                            val ip = serviceInfo.host?.hostAddress ?: return
                            if (ip in getLocalIpAddresses()) return
                            val parts = serviceInfo.serviceName.split("_")
                            val displayName = parts.getOrNull(1) ?: "Host"
                            val roomId = parts.getOrNull(2) ?: ip
                            val existing = roomsMap[roomId]
                            roomsMap[roomId] = DiscoveredRoom(
                                roomId = roomId,
                                hostName = existing?.hostName ?: displayName,
                                hostIp = ip,
                                port = serviceInfo.port,
                                mode = existing?.mode ?: GameMode.CLASSIC_QUEEN,
                                playerCount = existing?.playerCount ?: 1,
                                lastSeenMs = System.currentTimeMillis()
                            )
                            pruneAndPublishRooms()
                        }
                    })
                }
            }
            override fun onServiceLost(service: NsdServiceInfo) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
        }
        nsdDiscoveryListener = listener
        runCatching {
            manager.discoverServices(NSD_SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
        }
    }

    private fun stopNsdDiscovery() {
        val manager = nsdManager ?: return
        val listener = nsdDiscoveryListener ?: return
        nsdDiscoveryListener = null
        runCatching { manager.stopServiceDiscovery(listener) }
    }

    private fun acquireMulticastLock() {
        runCatching {
            if (multicastLock == null) {
                multicastLock = wifiManager?.createMulticastLock("CarromLanMulticastLock")?.apply {
                    setReferenceCounted(false)
                }
            }
            if (multicastLock?.isHeld == false) {
                multicastLock?.acquire()
            }
        }
    }

    private fun releaseMulticastLock() {
        runCatching {
            if (multicastLock?.isHeld == true) {
                multicastLock?.release()
            }
        }
    }

    private fun closeActiveSocketOnly() {
        pingJob?.cancel()
        pingJob = null
        readerJob?.cancel()
        readerJob = null
        synchronized(writeLock) {
            runCatching { writer?.close() }
            writer = null
        }
        runCatching { activeSocket?.close() }
        activeSocket = null
    }

    fun stopAll() {
        hostJob?.cancel()
        hostJob = null
        beaconJob?.cancel()
        beaconJob = null
        stopDiscovery()
        unregisterNsdService()
        closeActiveSocketOnly()
        runCatching { serverSocket?.close() }
        serverSocket = null
        releaseMulticastLock()
    }
}
