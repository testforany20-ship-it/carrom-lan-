package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.BoardTheme
import com.example.model.StrikerStyle
import com.example.model.UserPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlin.random.Random

private val Context.carromDataStore: DataStore<Preferences> by preferencesDataStore(name = "carrom_lan_prefs")

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val PLAYER_NAME = stringPreferencesKey("player_name")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val HAPTICS_ENABLED = booleanPreferencesKey("haptics_enabled")
        val BOARD_THEME = stringPreferencesKey("board_theme")
        val STRIKER_STYLE = stringPreferencesKey("striker_style")
        val MATCHES_PLAYED = intPreferencesKey("matches_played")
        val WINS = intPreferencesKey("wins")
    }

    private val defaultGuestName = "Player_${Random.nextInt(100, 999)}"

    val preferencesFlow: Flow<UserPreferences> = context.carromDataStore.data.map { prefs ->
        val themeName = prefs[Keys.BOARD_THEME] ?: BoardTheme.ROYAL_MAPLE.name
        val strikerName = prefs[Keys.STRIKER_STYLE] ?: StrikerStyle.IVORY_GOLD.name
        UserPreferences(
            playerName = prefs[Keys.PLAYER_NAME]?.takeIf { it.isNotBlank() } ?: defaultGuestName,
            soundEnabled = prefs[Keys.SOUND_ENABLED] ?: true,
            hapticsEnabled = prefs[Keys.HAPTICS_ENABLED] ?: true,
            boardTheme = runCatching { BoardTheme.valueOf(themeName) }.getOrDefault(BoardTheme.ROYAL_MAPLE),
            strikerStyle = runCatching { StrikerStyle.valueOf(strikerName) }.getOrDefault(StrikerStyle.IVORY_GOLD),
            matchesPlayed = prefs[Keys.MATCHES_PLAYED] ?: 0,
            wins = prefs[Keys.WINS] ?: 0
        )
    }

    suspend fun setPlayerName(name: String) {
        val clean = name.trim().take(16)
        if (clean.isNotEmpty()) {
            context.carromDataStore.edit { it[Keys.PLAYER_NAME] = clean }
        }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.carromDataStore.edit { it[Keys.SOUND_ENABLED] = enabled }
    }

    suspend fun setHapticsEnabled(enabled: Boolean) {
        context.carromDataStore.edit { it[Keys.HAPTICS_ENABLED] = enabled }
    }

    suspend fun setBoardTheme(theme: BoardTheme) {
        context.carromDataStore.edit { it[Keys.BOARD_THEME] = theme.name }
    }

    suspend fun setStrikerStyle(style: StrikerStyle) {
        context.carromDataStore.edit { it[Keys.STRIKER_STYLE] = style.name }
    }

    suspend fun recordMatchResult(won: Boolean) {
        context.carromDataStore.edit { prefs ->
            prefs[Keys.MATCHES_PLAYED] = (prefs[Keys.MATCHES_PLAYED] ?: 0) + 1
            if (won) {
                prefs[Keys.WINS] = (prefs[Keys.WINS] ?: 0) + 1
            }
        }
    }
}
