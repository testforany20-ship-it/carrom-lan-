package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.CarromSoundEngine
import com.example.data.UserPreferencesRepository
import com.example.engine.CarromPhysics
import com.example.model.AimState
import com.example.model.BoardTheme
import com.example.model.DiscState
import com.example.model.DiscType
import com.example.model.DiscoveredRoom
import com.example.model.GameMode
import com.example.model.LanConnectionRole
import com.example.model.LanLobbyState
import com.example.model.LobbyChatMessage
import com.example.model.MatchState
import com.example.model.MatchType
import com.example.model.PlayerSeat
import com.example.model.QueenState
import com.example.model.StrikerStyle
import com.example.model.TurnPhase
import com.example.model.UserPreferences
import com.example.network.LanMultiplayerManager
import com.example.network.LanPacketEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

sealed class UiNavEvent {
    data object NavigateToGame : UiNavEvent()
    data object NavigateToHome : UiNavEvent()
}

data class FloatingEmote(
    val id: String = UUID.randomUUID().toString(),
    val sender: String,
    val text: String
)

class CarromViewModel(application: Application) : AndroidViewModel(application) {

    private val prefsRepo = UserPreferencesRepository(application)
    val soundEngine = CarromSoundEngine()
    private val lanManager = LanMultiplayerManager(application)

    val preferences: StateFlow<UserPreferences> = prefsRepo.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferences())

    private val _matchState = MutableStateFlow(MatchState())
    val matchState: StateFlow<MatchState> = _matchState.asStateFlow()

    private val _localAim = MutableStateFlow(AimState())
    val localAim: StateFlow<AimState> = _localAim.asStateFlow()

    private val _lobbyState = MutableStateFlow(LanLobbyState())
    val lobbyState: StateFlow<LanLobbyState> = _lobbyState.asStateFlow()

    private val _floatingEmote = MutableStateFlow<FloatingEmote?>(null)
    val floatingEmote: StateFlow<FloatingEmote?> = _floatingEmote.asStateFlow()

    private val _navEvents = MutableSharedFlow<UiNavEvent>(extraBufferCapacity = 8)
    val navEvents: SharedFlow<UiNavEvent> = _navEvents.asSharedFlow()

    private val _hapticTrigger = MutableSharedFlow<Float>(extraBufferCapacity = 16)
    val hapticTrigger: SharedFlow<Float> = _hapticTrigger.asSharedFlow()

    private var physicsJob: Job? = null
    private var aiJob: Job? = null
    private var emoteJob: Job? = null
    private var lastSlideBroadcastMs = 0L
    private var lastAimBroadcastMs = 0L

    init {
        viewModelScope.launch {
            preferences.collect { prefs ->
                soundEngine.soundEnabled = prefs.soundEnabled
            }
        }

        viewModelScope.launch {
            lanManager.discoveredRooms.collect { rooms ->
                _lobbyState.update { it.copy(discoveredRooms = rooms) }
            }
        }

        viewModelScope.launch {
            lanManager.events.collect { event ->
                handleLanEvent(event)
            }
        }
    }

    // --- Preferences Actions ---

    fun updatePlayerName(name: String) {
        viewModelScope.launch { prefsRepo.setPlayerName(name) }
    }

    fun toggleSound() {
        viewModelScope.launch {
            prefsRepo.setSoundEnabled(!preferences.value.soundEnabled)
        }
    }

    fun toggleHaptics() {
        viewModelScope.launch {
            prefsRepo.setHapticsEnabled(!preferences.value.hapticsEnabled)
        }
    }

    fun selectBoardTheme(theme: BoardTheme) {
        viewModelScope.launch { prefsRepo.setBoardTheme(theme) }
    }

    fun selectStrikerStyle(style: StrikerStyle) {
        viewModelScope.launch { prefsRepo.setStrikerStyle(style) }
    }

    // --- Offline Match Starters ---

    fun startOfflineMatch(matchType: MatchType, mode: GameMode) {
        stopSimulationAndAi()
        lanManager.stopAll()
        _lobbyState.value = LanLobbyState()

        val myName = preferences.value.playerName
        val p2Name = if (matchType == MatchType.VS_AI) "Carrom Bot" else "Player 2"
        val initialDiscs = CarromPhysics.createInitialDiscs(mode)
        val striker = CarromPhysics.createStrikerForTurn(PlayerSeat.PLAYER_1, initialDiscs)

        _localAim.value = AimState()
        _matchState.value = MatchState(
            mode = mode,
            matchType = matchType,
            player1Name = myName,
            player2Name = p2Name,
            currentTurn = PlayerSeat.PLAYER_1,
            phase = TurnPhase.AIMING,
            discs = initialDiscs,
            striker = striker,
            queenState = if (mode == GameMode.DISC_POOL) QueenState.COVERED_P1 else QueenState.ON_BOARD,
            statusBanner = "$myName's break! Slide striker & pull back to shoot",
            strikerPlacementValid = true
        )
        _navEvents.tryEmit(UiNavEvent.NavigateToGame)
    }

    // --- LAN Hotspot & Wi-Fi Lobby Actions ---

    fun refreshNetworkInfo() {
        _lobbyState.update {
            it.copy(
                localIps = lanManager.getLocalIpAddresses(),
                suggestedHostIp = lanManager.getSuggestedHostIp()
            )
        }
    }

    fun startHostingRoom(mode: GameMode = _lobbyState.value.selectedMode) {
        val hostName = preferences.value.playerName
        lanManager.startHosting(hostName, mode)
        _lobbyState.value = LanLobbyState(
            role = LanConnectionRole.HOSTING,
            localIps = lanManager.getLocalIpAddresses(),
            suggestedHostIp = lanManager.getSuggestedHostIp(),
            hostName = hostName,
            guestName = null,
            guestReady = false,
            selectedMode = mode,
            chatMessages = listOf(
                LobbyChatMessage(
                    id = UUID.randomUUID().toString(),
                    sender = "System",
                    text = "Room created! Share Hotspot or same Wi-Fi with your friend.",
                    timestampMs = System.currentTimeMillis(),
                    isSystem = true
                )
            )
        )
    }

    fun startScanningRooms() {
        lanManager.stopAll()
        lanManager.startDiscovery()
        _lobbyState.value = LanLobbyState(
            role = LanConnectionRole.JOINING,
            localIps = lanManager.getLocalIpAddresses(),
            suggestedHostIp = lanManager.getSuggestedHostIp(),
            isScanning = true
        )
    }

    fun joinRoomByObject(room: DiscoveredRoom) {
        joinRoomByIp(room.hostIp, room.port)
    }

    fun joinRoomByIp(ip: String, port: Int = LanMultiplayerManager.DEFAULT_TCP_PORT) {
        val cleanIp = ip.trim()
        if (cleanIp.isBlank()) {
            _lobbyState.update { it.copy(errorMessage = "Enter a valid Host IP address") }
            return
        }
        _lobbyState.update { it.copy(errorMessage = null, isScanning = false) }
        lanManager.joinRoom(cleanIp, port, preferences.value.playerName)
    }

    fun clearLobbyError() {
        _lobbyState.update { it.copy(errorMessage = null) }
    }

    fun changeHostMode(mode: GameMode) {
        val lobby = _lobbyState.value
        if (lobby.role != LanConnectionRole.HOSTING && lobby.role != LanConnectionRole.CONNECTED_AS_HOST) return
        _lobbyState.update { it.copy(selectedMode = mode) }
        lanManager.updateHostBeaconState(mode, if (lobby.guestName != null) 2 else 1)
        if (lobby.guestName != null) {
            lanManager.sendLobbyState(
                hostName = lobby.hostName,
                guestName = lobby.guestName,
                guestReady = lobby.guestReady,
                mode = mode,
                started = false
            )
        }
    }

    fun toggleGuestReady() {
        val lobby = _lobbyState.value
        if (lobby.role != LanConnectionRole.CONNECTED_AS_CLIENT) return
        val newReady = !lobby.guestReady
        _lobbyState.update { it.copy(guestReady = newReady) }
        lanManager.sendGuestReady(newReady)
    }

    fun sendLobbyChat(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val me = preferences.value.playerName
        appendChat(me, clean)
        lanManager.sendChat(me, clean)
    }

    fun sendInGameEmote(text: String) {
        val me = preferences.value.playerName
        showFloatingEmote(me, text)
        lanManager.sendChat(me, text)
    }

    fun startLanMatchAsHost() {
        val lobby = _lobbyState.value
        if (lobby.role != LanConnectionRole.CONNECTED_AS_HOST) return
        val guestName = lobby.guestName ?: return
        val mode = lobby.selectedMode
        val hostName = lobby.hostName.ifBlank { preferences.value.playerName }

        lanManager.sendLobbyState(
            hostName = hostName,
            guestName = guestName,
            guestReady = lobby.guestReady,
            mode = mode,
            started = true
        )

        setupLanHostMatch(hostName, guestName, mode)
        _navEvents.tryEmit(UiNavEvent.NavigateToGame)
    }

    private fun setupLanHostMatch(hostName: String, guestName: String, mode: GameMode) {
        stopSimulationAndAi()
        val initialDiscs = CarromPhysics.createInitialDiscs(mode)
        val striker = CarromPhysics.createStrikerForTurn(PlayerSeat.PLAYER_1, initialDiscs)
        _localAim.value = AimState()
        val state = MatchState(
            mode = mode,
            matchType = MatchType.LAN_HOST,
            player1Name = hostName,
            player2Name = guestName,
            currentTurn = PlayerSeat.PLAYER_1,
            phase = TurnPhase.AIMING,
            discs = initialDiscs,
            striker = striker,
            queenState = if (mode == GameMode.DISC_POOL) QueenState.COVERED_P1 else QueenState.ON_BOARD,
            statusBanner = "$hostName's break! Slide striker & shoot",
            strikerPlacementValid = true
        )
        _matchState.value = state
        lanManager.sendGameSnapshot(state)
    }

    fun leaveLobbyOrMatch() {
        stopSimulationAndAi()
        lanManager.sendLeave()
        lanManager.stopAll()
        _lobbyState.value = LanLobbyState()
        _localAim.value = AimState()
    }

    fun requestRematch() {
        val state = _matchState.value
        when (state.matchType) {
            MatchType.VS_AI, MatchType.PASS_AND_PLAY -> {
                startOfflineMatch(state.matchType, state.mode)
            }
            MatchType.LAN_HOST -> {
                setupLanHostMatch(state.player1Name, state.player2Name, state.mode)
                lanManager.sendRematchRequest(state.player1Name)
            }
            MatchType.LAN_CLIENT -> {
                lanManager.sendRematchRequest(state.player2Name)
                _matchState.update {
                    it.copy(statusBanner = "Rematch requested! Waiting for ${it.player1Name}...")
                }
            }
        }
    }

    // --- Interactive Board Controls ---

    fun canLocalUserControlTurn(): Boolean {
        val s = _matchState.value
        if (s.phase != TurnPhase.AIMING) return false
        return when (s.matchType) {
            MatchType.VS_AI -> s.currentTurn == PlayerSeat.PLAYER_1
            MatchType.PASS_AND_PLAY -> true
            MatchType.LAN_HOST -> s.currentTurn == PlayerSeat.PLAYER_1
            MatchType.LAN_CLIENT -> s.currentTurn == PlayerSeat.PLAYER_2
        }
    }

    fun isBoardRotatedForLocalViewer(): Boolean {
        return _matchState.value.matchType == MatchType.LAN_CLIENT
    }

    /**
     * [normalizedX] is 0f..1f from LEFT to RIGHT of the local viewer's slider.
     */
    fun onStrikerSliderChanged(normalizedX: Float) {
        if (!canLocalUserControlTurn()) return
        val state = _matchState.value
        val canonicalX = if (isBoardRotatedForLocalViewer()) {
            CarromPhysics.BASELINE_MAX_X - normalizedX.coerceIn(0f, 1f) *
                (CarromPhysics.BASELINE_MAX_X - CarromPhysics.BASELINE_MIN_X)
        } else {
            CarromPhysics.BASELINE_MIN_X + normalizedX.coerceIn(0f, 1f) *
                (CarromPhysics.BASELINE_MAX_X - CarromPhysics.BASELINE_MIN_X)
        }

        val valid = CarromPhysics.isStrikerPositionValid(canonicalX, state.currentTurn, state.discs)
        _matchState.update {
            it.copy(
                striker = it.striker.copy(x = canonicalX),
                strikerPlacementValid = valid
            )
        }

        if (state.matchType == MatchType.LAN_HOST || state.matchType == MatchType.LAN_CLIENT) {
            val now = System.currentTimeMillis()
            if (now - lastSlideBroadcastMs > 45L) {
                lastSlideBroadcastMs = now
                lanManager.sendStrikerSlide(canonicalX)
            }
        }
    }

    /**
     * [pullDxCanonical], [pullDyCanonical] are already converted into canonical board space.
     */
    fun onAimDrag(isAiming: Boolean, pullDxCanonical: Float, pullDyCanonical: Float) {
        if (!canLocalUserControlTurn()) return
        val aim = AimState(isAiming, pullDxCanonical, pullDyCanonical)
        _localAim.value = aim

        val type = _matchState.value.matchType
        if (type == MatchType.LAN_HOST || type == MatchType.LAN_CLIENT) {
            val now = System.currentTimeMillis()
            if (!isAiming || now - lastAimBroadcastMs > 50L) {
                lastAimBroadcastMs = now
                lanManager.sendAimPreview(aim)
            }
        }
    }

    fun releaseShot(pullDxCanonical: Float, pullDyCanonical: Float) {
        _localAim.value = AimState()
        val state = _matchState.value
        if (!canLocalUserControlTurn() || !state.strikerPlacementValid) {
            if (state.matchType == MatchType.LAN_HOST || state.matchType == MatchType.LAN_CLIENT) {
                lanManager.sendAimPreview(AimState())
            }
            return
        }

        val velocity = CarromPhysics.computeShotVelocity(pullDxCanonical, pullDyCanonical)
        if (velocity == null) {
            if (state.matchType == MatchType.LAN_HOST || state.matchType == MatchType.LAN_CLIENT) {
                lanManager.sendAimPreview(AimState())
            }
            return
        }

        val (vx, vy) = velocity
        if (state.matchType == MatchType.LAN_CLIENT) {
            // Client sends authoritative shot request to Host
            lanManager.sendAimPreview(AimState())
            lanManager.sendShotCommand(state.striker.x, vx, vy)
            _matchState.update { it.copy(phase = TurnPhase.SIMULATING, statusBanner = "Shot fired!") }
        } else {
            executeAuthoritativeShot(state.striker.x, vx, vy)
        }
    }

    private fun executeAuthoritativeShot(strikerX: Float, vx: Float, vy: Float) {
        stopSimulationAndAi()
        soundEngine.playStrike()
        triggerHaptic(0.6f)

        val current = _matchState.value
        val firedStriker = current.striker.copy(
            x = strikerX,
            y = CarromPhysics.baselineY(current.currentTurn),
            vx = vx,
            vy = vy,
            pocketed = false,
            sinkProgress = 0f
        )

        val startState = current.copy(
            phase = TurnPhase.SIMULATING,
            striker = firedStriker,
            opponentAim = AimState(),
            statusBanner = ""
        )
        _matchState.value = startState
        if (startState.matchType == MatchType.LAN_HOST) {
            lanManager.sendGameSnapshot(startState)
        }

        physicsJob = viewModelScope.launch(Dispatchers.Default) {
            val workingDiscs = startState.discs.toMutableList()
            var workingStriker = firedStriker
            val pocketedThisTurn = mutableListOf<DiscType>()

            var lastNano = System.nanoTime()
            var lastNetBroadcast = 0L
            var elapsedSinceStop = 0f

            while (isActive) {
                delay(16)
                val nowNano = System.nanoTime()
                val dt = ((nowNano - lastNano) / 1_000_000_000f).coerceIn(0.008f, 0.032f)
                lastNano = nowNano

                val (nextStriker, events) = CarromPhysics.stepPhysics(dt, workingDiscs, workingStriker)
                workingStriker = nextStriker

                if (events.maxCoinImpact > 0.1f) {
                    soundEngine.playCoinHit(events.maxCoinImpact)
                    if (events.maxCoinImpact > 0.45f) triggerHaptic(events.maxCoinImpact)
                }
                if (events.maxWallImpact > 0.15f) {
                    soundEngine.playWallBounce(events.maxWallImpact)
                }
                if (events.pocketedDiscs.isNotEmpty()) {
                    pocketedThisTurn.addAll(events.pocketedDiscs)
                    for (p in events.pocketedDiscs) {
                        when (p) {
                            DiscType.STRIKER -> soundEngine.playFoul()
                            DiscType.QUEEN -> soundEngine.playQueen()
                            else -> soundEngine.playPocket()
                        }
                    }
                    triggerHaptic(0.85f)
                }

                val midSnapshot = _matchState.value.copy(
                    discs = workingDiscs.toList(),
                    striker = workingStriker,
                    phase = TurnPhase.SIMULATING
                )
                _matchState.value = midSnapshot

                if (startState.matchType == MatchType.LAN_HOST) {
                    val nowMs = System.currentTimeMillis()
                    if (nowMs - lastNetBroadcast >= 33L) {
                        lastNetBroadcast = nowMs
                        lanManager.sendGameSnapshot(midSnapshot)
                    }
                }

                if (events.allStopped) {
                    elapsedSinceStop += dt
                    val allSinkFinished = workingDiscs.none { it.pocketed && it.sinkProgress < 1f } &&
                        (!workingStriker.pocketed || workingStriker.sinkProgress >= 1f)
                    if (allSinkFinished && elapsedSinceStop > 0.15f) {
                        break
                    }
                } else {
                    elapsedSinceStop = 0f
                }
            }

            val resolved = CarromPhysics.evaluateTurnResult(
                previousState = startState,
                updatedDiscs = workingDiscs,
                pocketedThisTurn = pocketedThisTurn
            )
            _matchState.value = resolved

            if (resolved.phase == TurnPhase.MATCH_OVER) {
                soundEngine.playWin()
                val iWon = when (resolved.matchType) {
                    MatchType.VS_AI, MatchType.LAN_HOST -> resolved.winner == PlayerSeat.PLAYER_1
                    MatchType.LAN_CLIENT -> resolved.winner == PlayerSeat.PLAYER_2
                    MatchType.PASS_AND_PLAY -> true
                }
                if (resolved.matchType != MatchType.PASS_AND_PLAY) {
                    prefsRepo.recordMatchResult(iWon)
                }
            }

            if (resolved.matchType == MatchType.LAN_HOST) {
                lanManager.sendGameSnapshot(resolved)
            }

            if (resolved.phase == TurnPhase.AIMING &&
                resolved.matchType == MatchType.VS_AI &&
                resolved.currentTurn == PlayerSeat.PLAYER_2
            ) {
                scheduleAiTurn(resolved)
            }
        }
    }

    private fun scheduleAiTurn(state: MatchState) {
        aiJob?.cancel()
        aiJob = viewModelScope.launch {
            _matchState.update { it.copy(statusBanner = "${it.player2Name} is lining up a shot...") }
            delay(850)
            val (sx, vx, vy) = CarromPhysics.computeAiShot(state)
            // Slide striker visibly first
            _matchState.update { it.copy(striker = it.striker.copy(x = sx)) }
            delay(450)
            executeAuthoritativeShot(sx, vx, vy)
        }
    }

    private fun handleLanEvent(event: LanPacketEvent) {
        when (event) {
            is LanPacketEvent.ClientConnected -> {
                val lobby = _lobbyState.value
                _lobbyState.update {
                    it.copy(
                        role = LanConnectionRole.CONNECTED_AS_HOST,
                        guestName = event.guestName,
                        guestReady = false,
                        errorMessage = null
                    )
                }
                lanManager.updateHostBeaconState(lobby.selectedMode, 2)
                lanManager.sendLobbyState(
                    hostName = lobby.hostName,
                    guestName = event.guestName,
                    guestReady = false,
                    mode = lobby.selectedMode,
                    started = false
                )
                appendChat("System", "${event.guestName} joined the room!")
            }

            is LanPacketEvent.JoinAccepted -> {
                _lobbyState.update {
                    it.copy(
                        role = LanConnectionRole.CONNECTED_AS_CLIENT,
                        hostName = event.hostName,
                        guestName = preferences.value.playerName,
                        guestReady = false,
                        selectedMode = event.mode,
                        connectedHostIp = event.hostIp,
                        isScanning = false,
                        errorMessage = null,
                        chatMessages = listOf(
                            LobbyChatMessage(
                                id = UUID.randomUUID().toString(),
                                sender = "System",
                                text = "Connected to ${event.hostName}'s room!",
                                timestampMs = System.currentTimeMillis(),
                                isSystem = true
                            )
                        )
                    )
                }
            }

            is LanPacketEvent.JoinRejected -> {
                _lobbyState.update {
                    it.copy(
                        role = LanConnectionRole.JOINING,
                        errorMessage = event.reason,
                        isScanning = true
                    )
                }
                lanManager.startDiscovery()
            }

            is LanPacketEvent.LobbyUpdated -> {
                val alreadyInGame = _lobbyState.value.role == LanConnectionRole.CONNECTED_AS_CLIENT
                _lobbyState.update {
                    it.copy(
                        hostName = event.hostName,
                        guestName = event.guestName ?: it.guestName,
                        guestReady = event.guestReady,
                        selectedMode = event.mode
                    )
                }
                if (event.matchStarted && alreadyInGame) {
                    _matchState.value = MatchState(
                        mode = event.mode,
                        matchType = MatchType.LAN_CLIENT,
                        player1Name = event.hostName,
                        player2Name = preferences.value.playerName,
                        discs = CarromPhysics.createInitialDiscs(event.mode),
                        statusBanner = "Match starting..."
                    )
                    _navEvents.tryEmit(UiNavEvent.NavigateToGame)
                }
            }

            is LanPacketEvent.GuestReadyChanged -> {
                _lobbyState.update { it.copy(guestReady = event.ready) }
                val guest = _lobbyState.value.guestName ?: "Friend"
                appendChat("System", if (event.ready) "$guest is READY!" else "$guest cancelled ready")
            }

            is LanPacketEvent.ChatReceived -> {
                appendChat(event.sender, event.text)
                showFloatingEmote(event.sender, event.text)
            }

            is LanPacketEvent.StrikerSlide -> {
                _matchState.update { state ->
                    val valid = CarromPhysics.isStrikerPositionValid(event.x, state.currentTurn, state.discs)
                    state.copy(
                        striker = state.striker.copy(x = event.x),
                        strikerPlacementValid = valid
                    )
                }
            }

            is LanPacketEvent.AimPreview -> {
                _matchState.update { it.copy(opponentAim = event.aim) }
            }

            is LanPacketEvent.ShotCommand -> {
                if (_matchState.value.matchType == MatchType.LAN_HOST &&
                    _matchState.value.currentTurn == PlayerSeat.PLAYER_2 &&
                    _matchState.value.phase == TurnPhase.AIMING
                ) {
                    executeAuthoritativeShot(event.strikerX, event.vx, event.vy)
                }
            }

            is LanPacketEvent.SnapshotReceived -> {
                val prev = _matchState.value
                val incoming = event.snapshot
                // Trigger sound effects cleanly on client side when pocket counts change
                val prevPocketed = prev.discs.count { it.pocketed }
                val newPocketed = incoming.discs.count { it.pocketed }
                if (newPocketed > prevPocketed) {
                    soundEngine.playPocket()
                    triggerHaptic(0.75f)
                } else if (prev.phase == TurnPhase.AIMING && incoming.phase == TurnPhase.SIMULATING) {
                    soundEngine.playStrike()
                }
                if (prev.phase != TurnPhase.MATCH_OVER && incoming.phase == TurnPhase.MATCH_OVER) {
                    soundEngine.playWin()
                    val iWon = incoming.winner == PlayerSeat.PLAYER_2
                    viewModelScope.launch { prefsRepo.recordMatchResult(iWon) }
                }
                _matchState.value = incoming.copy(
                    opponentAim = if (incoming.phase == TurnPhase.AIMING) prev.opponentAim else AimState()
                )
            }

            is LanPacketEvent.RematchRequested -> {
                if (_matchState.value.matchType == MatchType.LAN_HOST) {
                    val s = _matchState.value
                    setupLanHostMatch(s.player1Name, s.player2Name, s.mode)
                    showFloatingEmote(event.fromName, "Rematch started!")
                } else {
                    showFloatingEmote(event.fromName, "Rematch started!")
                }
            }

            is LanPacketEvent.PingUpdated -> {
                _lobbyState.update { it.copy(pingMs = event.pingMs) }
            }

            is LanPacketEvent.Disconnected -> {
                val role = _lobbyState.value.role
                if (role == LanConnectionRole.CONNECTED_AS_HOST) {
                    // Host drops back to waiting for a friend
                    val mode = _lobbyState.value.selectedMode
                    _lobbyState.update {
                        it.copy(
                            role = LanConnectionRole.HOSTING,
                            guestName = null,
                            guestReady = false,
                            errorMessage = event.reason
                        )
                    }
                    lanManager.updateHostBeaconState(mode, 1)
                    appendChat("System", event.reason)
                    if (_matchState.value.matchType == MatchType.LAN_HOST) {
                        _matchState.update {
                            it.copy(
                                phase = TurnPhase.MATCH_OVER,
                                winner = PlayerSeat.PLAYER_1,
                                winReason = "Friend disconnected from LAN room",
                                statusBanner = "Opponent disconnected"
                            )
                        }
                    }
                } else if (role == LanConnectionRole.CONNECTED_AS_CLIENT) {
                    _lobbyState.update {
                        it.copy(
                            role = LanConnectionRole.JOINING,
                            errorMessage = event.reason
                        )
                    }
                    if (_matchState.value.matchType == MatchType.LAN_CLIENT) {
                        _matchState.update {
                            it.copy(
                                phase = TurnPhase.MATCH_OVER,
                                winner = null,
                                winReason = event.reason,
                                statusBanner = "Disconnected from host"
                            )
                        }
                    }
                }
            }
        }
    }

    private fun appendChat(sender: String, text: String) {
        val msg = LobbyChatMessage(
            id = UUID.randomUUID().toString(),
            sender = sender,
            text = text,
            timestampMs = System.currentTimeMillis(),
            isSystem = sender == "System"
        )
        _lobbyState.update {
            it.copy(chatMessages = (it.chatMessages + msg).takeLast(30))
        }
    }

    private fun showFloatingEmote(sender: String, text: String) {
        emoteJob?.cancel()
        _floatingEmote.value = FloatingEmote(sender = sender, text = text)
        emoteJob = viewModelScope.launch {
            delay(2800)
            _floatingEmote.value = null
        }
    }

    private fun triggerHaptic(intensity: Float) {
        if (preferences.value.hapticsEnabled) {
            _hapticTrigger.tryEmit(intensity)
        }
    }

    private fun stopSimulationAndAi() {
        physicsJob?.cancel()
        physicsJob = null
        aiJob?.cancel()
        aiJob = null
    }

    override fun onCleared() {
        super.onCleared()
        stopSimulationAndAi()
        lanManager.stopAll()
        soundEngine.release()
    }
}
