package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Royal Carrom Lounge Palette
val MahoganyVoid = Color(0xFF120C09)
val EspressoSurface = Color(0xFF1D1410)
val WalnutCard = Color(0xFF281B15)
val CedarElevated = Color(0xFF34241C)
val WarmBorder = Color(0xFF4A3429)

val ChampagneGold = Color(0xFFF2B705)
val AmberGold = Color(0xFFD99B26)
val SoftGoldText = Color(0xFFFFE082)

val QueenCrimson = Color(0xFFD93829)
val QueenDark = Color(0xFF8C1C13)
val EmeraldOnline = Color(0xFF2E9E6B)
val EmeraldGlow = Color(0xFF4CD995)
val SkyLan = Color(0xFF38BDF8)

val IvoryText = Color(0xFFF7EFE6)
val SandMutedText = Color(0xFFC5B3A3)
val SubtleMutedText = Color(0xFF8E7A6B)

// Board & Discs Palette (centralized for customization themes)
val BoardMapleLight = Color(0xFFF6E3C3)
val BoardMapleMid = Color(0xFFEBCEA0)
val BoardFrameOuter = Color(0xFF432517)
val BoardFrameInner = Color(0xFF2A160D)
val BoardLineDark = Color(0xFF3B2418)
val BoardAccentCrimson = Color(0xFFC62828)

val WhiteCoinFill = Color(0xFFF9F1E1)
val WhiteCoinRim = Color(0xFFD4BEA0)
val BlackCoinFill = Color(0xFF25201E)
val BlackCoinRim = Color(0xFF4A403C)
val StrikerIvory = Color(0xFFFFFBF2)
val StrikerGoldRing = Color(0xFFF2B705)
