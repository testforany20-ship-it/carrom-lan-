package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.engine.CarromPhysics
import com.example.model.AimState
import com.example.model.DiscType
import com.example.model.GameMode
import com.example.model.MatchState
import com.example.model.MatchType
import com.example.model.PlayerSeat
import com.example.model.QueenState
import com.example.model.TurnPhase
import com.example.model.UserPreferences
import com.example.ui.components.CarromBoardCanvas
import com.example.ui.theme.BlackCoinFill
import com.example.ui.theme.BlackCoinRim
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.EmeraldOnline
import com.example.ui.theme.QueenCrimson
import com.example.ui.theme.WhiteCoinFill
import com.example.ui.theme.WhiteCoinRim
import com.example.viewmodel.FloatingEmote

@Composable
fun GameScreen(
    matchState: MatchState,
    localAim: AimState,
    preferences: UserPreferences,
    pingMs: Int,
    floatingEmote: FloatingEmote?,
    isBoardRotated: Boolean,
    canInteract: Boolean,
    onSliderChanged: (Float) -> Unit,
    onAimUpdate: (Boolean, Float, Float) -> Unit,
    onShoot: (Float, Float) -> Unit,
    onToggleSound: () -> Unit,
    onSendEmote: (String) -> Unit,
    onRematch: () -> Unit,
    onExitMatch: () -> Unit
) {
    var showLeaveConfirm by remember { mutableStateOf(false) }

    BackHandler {
        if (matchState.phase == TurnPhase.MATCH_OVER) {
            onExitMatch()
        } else {
            showLeaveConfirm = true
        }
    }

    val isLan = matchState.matchType == MatchType.LAN_HOST || matchState.matchType == MatchType.LAN_CLIENT

    val topSeat = if (isBoardRotated) PlayerSeat.PLAYER_1 else PlayerSeat.PLAYER_2
    val bottomSeat = if (isBoardRotated) PlayerSeat.PLAYER_2 else PlayerSeat.PLAYER_1

    val sliderSpan = (CarromPhysics.BASELINE_MAX_X - CarromPhysics.BASELINE_MIN_X).coerceAtLeast(1f)
    val sliderFraction = if (isBoardRotated) {
        ((CarromPhysics.BASELINE_MAX_X - matchState.striker.x) / sliderSpan).coerceIn(0f, 1f)
    } else {
        ((matchState.striker.x - CarromPhysics.BASELINE_MIN_X) / sliderSpan).coerceIn(0f, 1f)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.background,
                        MaterialTheme.colorScheme.surface,
                        MaterialTheme.colorScheme.background
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 620.dp)
                .align(Alignment.TopCenter)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Top Arena Controls Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    IconButton(
                        onClick = {
                            if (matchState.phase == TurnPhase.MATCH_OVER) onExitMatch() else showLeaveConfirm = true
                        },
                        modifier = Modifier.testTag("game_exit_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Leave match"
                        )
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Text(
                            text = matchState.mode.title,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }

                    if (isLan && pingMs > 0) {
                        Surface(
                            color = EmeraldOnline.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = "${pingMs}ms",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldGlow,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onToggleSound,
                    modifier = Modifier.testTag("game_sound_button")
                ) {
                    Icon(
                        imageVector = if (preferences.soundEnabled) {
                            Icons.AutoMirrored.Rounded.VolumeUp
                        } else {
                            Icons.AutoMirrored.Rounded.VolumeOff
                        },
                        contentDescription = "Toggle sound"
                    )
                }
            }

            // Top Player HUD
            PlayerScoreHud(
                seat = topSeat,
                matchState = matchState,
                isLocalPlayer = matchState.matchType == MatchType.PASS_AND_PLAY && matchState.currentTurn == topSeat
            )

            // Status Banner + Floating Emote
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = if (!matchState.strikerPlacementValid && canInteract) {
                        QueenCrimson.copy(alpha = 0.22f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
                    },
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(
                        1.dp,
                        if (!matchState.strikerPlacementValid && canInteract) {
                            QueenCrimson
                        } else {
                            MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
                        }
                    )
                ) {
                    val bannerText = when {
                        !matchState.strikerPlacementValid && canInteract -> "Overlap! Slide striker to a clear spot"
                        matchState.statusBanner.isNotBlank() -> matchState.statusBanner
                        canInteract -> "Pull back from striker to aim & shoot"
                        else -> "Shot in motion..."
                    }
                    Text(
                        text = bannerText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }

                this@Column.AnimatedVisibility(
                    visible = floatingEmote != null,
                    enter = fadeIn() + scaleIn(),
                    exit = fadeOut() + scaleOut()
                ) {
                    floatingEmote?.let { emote ->
                        Surface(
                            color = MaterialTheme.colorScheme.primary,
                            shape = RoundedCornerShape(50),
                            shadowElevation = 6.dp
                        ) {
                            Text(
                                text = "${emote.sender}: ${emote.text}",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Centerpiece Carrom Board
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                CarromBoardCanvas(
                    matchState = matchState,
                    localAim = localAim,
                    boardTheme = preferences.boardTheme,
                    strikerStyle = preferences.strikerStyle,
                    isBoardRotated = isBoardRotated,
                    canInteract = canInteract,
                    onAimUpdate = onAimUpdate,
                    onShoot = onShoot,
                    modifier = Modifier
                        .aspectRatio(1f)
                        .testTag("carrom_board_canvas")
                )
            }

            // Striker Baseline Slider Rail
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(
                    1.dp,
                    if (canInteract) MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
                    else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "SLIDE",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (canInteract) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Slider(
                        value = sliderFraction,
                        onValueChange = onSliderChanged,
                        enabled = canInteract && matchState.phase == TurnPhase.AIMING,
                        colors = SliderDefaults.colors(
                            thumbColor = if (matchState.strikerPlacementValid) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                QueenCrimson
                            },
                            activeTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                            inactiveTrackColor = MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("striker_slider")
                    )
                }
            }

            // Bottom Player HUD
            PlayerScoreHud(
                seat = bottomSeat,
                matchState = matchState,
                isLocalPlayer = true
            )

            // Quick LAN Emote Chips
            if (isLan) {
                val emotes = listOf("Nice shot!", "Close!", "Oops!", "GG!", "Your turn")
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(emotes) { msg ->
                        AssistChip(
                            onClick = { onSendEmote(msg) },
                            label = { Text(msg, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }
        }
    }

    if (showLeaveConfirm) {
        AlertDialog(
            onDismissRequest = { showLeaveConfirm = false },
            title = { Text("Leave Match?") },
            text = {
                Text(
                    if (isLan) "Leaving will disconnect from the LAN room."
                    else "Your current board progress will be lost."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showLeaveConfirm = false
                        onExitMatch()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = QueenCrimson),
                    modifier = Modifier.testTag("confirm_leave_match")
                ) {
                    Text("Leave")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLeaveConfirm = false }) {
                    Text("Keep Playing")
                }
            }
        )
    }

    if (matchState.phase == TurnPhase.MATCH_OVER) {
        val winnerName = when (matchState.winner) {
            PlayerSeat.PLAYER_1 -> matchState.player1Name
            PlayerSeat.PLAYER_2 -> matchState.player2Name
            null -> "Match Ended"
        }
        AlertDialog(
            onDismissRequest = {},
            icon = {
                Icon(
                    imageVector = Icons.Rounded.EmojiEvents,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(44.dp)
                )
            },
            title = {
                Text(
                    text = if (matchState.winner != null) "$winnerName Wins!" else "Match Ended",
                    style = MaterialTheme.typography.headlineMedium
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = matchState.winReason,
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = MaterialTheme.shapes.small,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${matchState.player1Name}: ${matchState.p1Score}")
                            Text("${matchState.player2Name}: ${matchState.p2Score}")
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = onRematch,
                    modifier = Modifier.testTag("rematch_button")
                ) {
                    Icon(Icons.Rounded.Replay, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Rematch")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = onExitMatch,
                    modifier = Modifier.testTag("exit_after_match_button")
                ) {
                    Text("Exit")
                }
            }
        )
    }
}

@Composable
private fun PlayerScoreHud(
    seat: PlayerSeat,
    matchState: MatchState,
    isLocalPlayer: Boolean
) {
    val isTurn = matchState.currentTurn == seat && matchState.phase != TurnPhase.MATCH_OVER
    val name = if (seat == PlayerSeat.PLAYER_1) matchState.player1Name else matchState.player2Name
    val score = if (seat == PlayerSeat.PLAYER_1) matchState.p1Score else matchState.p2Score
    val pocketed = if (seat == PlayerSeat.PLAYER_1) matchState.p1PocketedCount else matchState.p2PocketedCount
    val coinFill = if (seat == PlayerSeat.PLAYER_1) WhiteCoinFill else BlackCoinFill
    val coinRim = if (seat == PlayerSeat.PLAYER_1) WhiteCoinRim else BlackCoinRim

    val hasQueenBadge = when (seat) {
        PlayerSeat.PLAYER_1 -> matchState.queenState == QueenState.COVERED_P1 ||
            matchState.queenState == QueenState.NEEDS_COVER_P1
        PlayerSeat.PLAYER_2 -> matchState.queenState == QueenState.COVERED_P2 ||
            matchState.queenState == QueenState.NEEDS_COVER_P2
    }
    val queenCovered = (seat == PlayerSeat.PLAYER_1 && matchState.queenState == QueenState.COVERED_P1) ||
        (seat == PlayerSeat.PLAYER_2 && matchState.queenState == QueenState.COVERED_P2)

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(
            width = if (isTurn) 1.6.dp else 1.dp,
            color = if (isTurn) EmeraldGlow else MaterialTheme.colorScheme.outline.copy(alpha = 0.65f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (matchState.mode != GameMode.POINTS_29) {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(coinFill)
                            .border(2.dp, coinRim, CircleShape)
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    )
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = name,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (hasQueenBadge) {
                            Surface(
                                color = if (queenCovered) QueenCrimson else MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = if (queenCovered) "QUEEN +3" else "COVER!",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    if (isTurn) {
                        Text(
                            text = if (isLocalPlayer) "YOUR TURN" else "ACTIVE TURN",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldGlow,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Surface(
                color = MaterialTheme.colorScheme.background,
                shape = MaterialTheme.shapes.small
            ) {
                Text(
                    text = if (matchState.mode == GameMode.POINTS_29) {
                        "$score pts"
                    } else {
                        "$pocketed / 9"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }
}
