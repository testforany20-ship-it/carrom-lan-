package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val CarromDarkColorScheme = darkColorScheme(
    primary = ChampagneGold,
    onPrimary = MahoganyVoid,
    primaryContainer = CedarElevated,
    onPrimaryContainer = SoftGoldText,
    secondary = EmeraldOnline,
    onSecondary = MahoganyVoid,
    secondaryContainer = Color(0xFF143828),
    onSecondaryContainer = EmeraldGlow,
    tertiary = QueenCrimson,
    onTertiary = IvoryText,
    background = MahoganyVoid,
    onBackground = IvoryText,
    surface = EspressoSurface,
    onSurface = IvoryText,
    surfaceVariant = WalnutCard,
    onSurfaceVariant = SandMutedText,
    outline = WarmBorder,
    error = QueenCrimson,
    onError = IvoryText
)

private val CarromShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp)
)

@Composable
fun CarromTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CarromDarkColorScheme,
        typography = CarromTypography,
        shapes = CarromShapes,
        content = content
    )
}
