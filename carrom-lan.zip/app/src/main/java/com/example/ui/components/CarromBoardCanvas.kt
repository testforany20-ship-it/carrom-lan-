package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import com.example.engine.CarromPhysics
import com.example.model.AimState
import com.example.model.BoardTheme
import com.example.model.DiscState
import com.example.model.DiscType
import com.example.model.MatchState
import com.example.model.StrikerStyle
import com.example.model.TurnPhase
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

@Composable
fun CarromBoardCanvas(
    matchState: MatchState,
    localAim: AimState,
    boardTheme: BoardTheme,
    strikerStyle: StrikerStyle,
    isBoardRotated: Boolean,
    canInteract: Boolean,
    onAimUpdate: (Boolean, Float, Float) -> Unit,
    onShoot: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentMatch by rememberUpdatedState(matchState)
    val currentCanInteract by rememberUpdatedState(canInteract)
    val currentRotated by rememberUpdatedState(isBoardRotated)
    val currentOnAim by rememberUpdatedState(onAimUpdate)
    val currentOnShoot by rememberUpdatedState(onShoot)

    var activeDragStartBoard by remember { mutableStateOf<Offset?>(null) }
    var currentPullCanonical by remember { mutableStateOf(Offset.Zero) }

    Box(modifier = modifier.aspectRatio(1f)) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { touchPx ->
                            if (!currentCanInteract || currentMatch.phase != TurnPhase.AIMING) {
                                activeDragStartBoard = null
                                return@detectDragGestures
                            }
                            val scale = size.width / CarromPhysics.BOARD_SIZE
                            if (scale <= 0f) return@detectDragGestures
                            val viewX = touchPx.x / scale
                            val viewY = touchPx.y / scale
                            val canonX = if (currentRotated) CarromPhysics.BOARD_SIZE - viewX else viewX
                            val canonY = if (currentRotated) CarromPhysics.BOARD_SIZE - viewY else viewY

                            val s = currentMatch.striker
                            val dist = hypot(canonX - s.x, canonY - s.y)
                            if (dist <= 115f) {
                                activeDragStartBoard = Offset(s.x, s.y)
                                currentPullCanonical = Offset.Zero
                                currentOnAim(true, 0f, 0f)
                            } else {
                                activeDragStartBoard = null
                            }
                        },
                        onDrag = { change, _ ->
                            val start = activeDragStartBoard ?: return@detectDragGestures
                            change.consume()
                            val scale = size.width / CarromPhysics.BOARD_SIZE
                            if (scale <= 0f) return@detectDragGestures
                            val viewX = change.position.x / scale
                            val viewY = change.position.y / scale
                            val canonX = if (currentRotated) CarromPhysics.BOARD_SIZE - viewX else viewX
                            val canonY = if (currentRotated) CarromPhysics.BOARD_SIZE - viewY else viewY

                            var dx = canonX - start.x
                            var dy = canonY - start.y
                            val len = hypot(dx, dy)
                            if (len > CarromPhysics.MAX_PULL_DISTANCE) {
                                val factor = CarromPhysics.MAX_PULL_DISTANCE / len
                                dx *= factor
                                dy *= factor
                            }
                            currentPullCanonical = Offset(dx, dy)
                            currentOnAim(true, dx, dy)
                        },
                        onDragEnd = {
                            if (activeDragStartBoard != null) {
                                currentOnShoot(currentPullCanonical.x, currentPullCanonical.y)
                            }
                            activeDragStartBoard = null
                            currentPullCanonical = Offset.Zero
                        },
                        onDragCancel = {
                            activeDragStartBoard = null
                            currentPullCanonical = Offset.Zero
                            currentOnAim(false, 0f, 0f)
                        }
                    )
                }
        ) {
            val boardPx = size.minDimension
            val scale = boardPx / CarromPhysics.BOARD_SIZE

            fun toScreenX(canonX: Float): Float {
                val x = if (isBoardRotated) CarromPhysics.BOARD_SIZE - canonX else canonX
                return x * scale
            }

            fun toScreenY(canonY: Float): Float {
                val y = if (isBoardRotated) CarromPhysics.BOARD_SIZE - canonY else canonY
                return y * scale
            }

            fun toScreen(canonX: Float, canonY: Float): Offset =
                Offset(toScreenX(canonX), toScreenY(canonY))

            // 1. Outer Wooden Frame & Inner Surface
            drawCarromBoardSurface(boardTheme, boardPx, scale, ::toScreen)

            // 2. Corner Pockets
            for ((px, py) in CarromPhysics.POCKET_CENTERS) {
                val center = toScreen(px, py)
                val pocketR = CarromPhysics.POCKET_RADIUS * scale
                // Brass outer collar
                drawCircle(
                    color = Color(0xFF8A6532),
                    radius = pocketR + 4f * scale,
                    center = center
                )
                // Deep dark pit gradient
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF050302), Color(0xFF1A0F0A)),
                        center = center,
                        radius = pocketR
                    ),
                    radius = pocketR,
                    center = center
                )
                // Inner rim shadow
                drawCircle(
                    color = Color(0x66000000),
                    radius = pocketR - 2f * scale,
                    center = center,
                    style = Stroke(width = 3f * scale)
                )
            }

            // 3. Aim Guide (Local or Opponent Preview)
            val activeAim = when {
                canInteract && localAim.isAiming -> localAim
                !canInteract && matchState.opponentAim.isAiming -> matchState.opponentAim
                else -> null
            }

            if (matchState.phase == TurnPhase.AIMING && activeAim != null && activeAim.isAiming) {
                drawAimOverlay(
                    striker = matchState.striker,
                    aim = activeAim,
                    discs = matchState.discs,
                    placementValid = matchState.strikerPlacementValid,
                    scale = scale,
                    toScreen = ::toScreen,
                    isRotated = isBoardRotated
                )
            }

            // 4. Coins (Pocketed sinking coins first, then active coins)
            val sortedDiscs = matchState.discs.sortedByDescending { it.pocketed }
            for (disc in sortedDiscs) {
                if (disc.pocketed && disc.sinkProgress >= 1f) continue
                drawCoin(disc, scale, ::toScreen)
            }

            // 5. Striker
            val striker = matchState.striker
            if (!striker.pocketed || striker.sinkProgress < 1f) {
                drawStriker(
                    striker = striker,
                    style = strikerStyle,
                    isActiveTurn = matchState.phase == TurnPhase.AIMING,
                    isValidPlacement = matchState.strikerPlacementValid,
                    canInteract = canInteract,
                    scale = scale,
                    toScreen = ::toScreen
                )
            }
        }
    }
}

private fun DrawScope.drawCarromBoardSurface(
    theme: BoardTheme,
    boardPx: Float,
    scale: Float,
    toScreen: (Float, Float) -> Offset
) {
    val frameOuter = Color(theme.frameOuterHex)
    val frameInner = Color(theme.frameInnerHex)
    val surfLight = Color(theme.surfaceLightHex)
    val surfMid = Color(theme.surfaceMidHex)
    val lineColor = Color(theme.lineColorHex)
    val accentColor = Color(theme.accentColorHex)

    // Outer mahogany/club frame
    drawRoundRect(
        brush = Brush.linearGradient(
            colors = listOf(frameOuter, frameInner, frameOuter),
            start = Offset.Zero,
            end = Offset(boardPx, boardPx)
        ),
        cornerRadius = CornerRadius(24f * scale, 24f * scale),
        size = Size(boardPx, boardPx)
    )

    // Gold/brass hairline border around frame
    drawRoundRect(
        color = Color(0x55F2B705),
        topLeft = Offset(6f * scale, 6f * scale),
        size = Size(boardPx - 12f * scale, boardPx - 12f * scale),
        cornerRadius = CornerRadius(20f * scale, 20f * scale),
        style = Stroke(width = 2.5f * scale)
    )

    // Inner playable surface
    val inset = CarromPhysics.PLAY_MIN * scale
    val innerSize = (CarromPhysics.PLAY_MAX - CarromPhysics.PLAY_MIN) * scale
    drawRoundRect(
        brush = Brush.radialGradient(
            colors = listOf(surfLight, surfMid),
            center = Offset(boardPx / 2f, boardPx / 2f),
            radius = innerSize * 0.72f
        ),
        topLeft = Offset(inset, inset),
        size = Size(innerSize, innerSize),
        cornerRadius = CornerRadius(14f * scale, 14f * scale)
    )

    // Subtle inner bevel shadow along frame cushion
    drawRoundRect(
        color = Color(0x44000000),
        topLeft = Offset(inset, inset),
        size = Size(innerSize, innerSize),
        cornerRadius = CornerRadius(14f * scale, 14f * scale),
        style = Stroke(width = 5f * scale)
    )

    val center = toScreen(500f, 500f)

    // Center Circle & Traditional 8-point Carrom Star
    drawCircle(
        color = lineColor.copy(alpha = 0.75f),
        radius = 128f * scale,
        center = center,
        style = Stroke(width = 2.6f * scale)
    )
    drawCircle(
        color = accentColor.copy(alpha = 0.65f),
        radius = 118f * scale,
        center = center,
        style = Stroke(width = 1.4f * scale)
    )

    // 8-point geometric star inside center circle
    val starPath = Path()
    val outerStarR = 114f * scale
    val innerStarR = 36f * scale
    for (i in 0 until 16) {
        val r = if (i % 2 == 0) outerStarR else innerStarR
        val angle = (i * PI / 8.0) - PI / 2.0
        val px = center.x + (r * cos(angle)).toFloat()
        val py = center.y + (r * sin(angle)).toFloat()
        if (i == 0) starPath.moveTo(px, py) else starPath.lineTo(px, py)
    }
    starPath.close()
    drawPath(
        path = starPath,
        color = accentColor.copy(alpha = 0.14f)
    )
    drawPath(
        path = starPath,
        color = lineColor.copy(alpha = 0.45f),
        style = Stroke(width = 1.6f * scale)
    )

    // Queen center spot ring
    drawCircle(
        color = accentColor.copy(alpha = 0.75f),
        radius = 27f * scale,
        center = center,
        style = Stroke(width = 2.4f * scale)
    )

    // 4 Baselines (Top, Bottom, Left, Right like an authentic Carrom board)
    val baseMin = CarromPhysics.BASELINE_MIN_X
    val baseMax = CarromPhysics.BASELINE_MAX_X
    val halfBand = 16f

    // Horizontal baselines (Top & Bottom)
    for (by in listOf(CarromPhysics.BASELINE_P1_Y, CarromPhysics.BASELINE_P2_Y)) {
        val pOuter1 = toScreen(baseMin, by - halfBand)
        val pOuter2 = toScreen(baseMax, by - halfBand)
        val pInner1 = toScreen(baseMin, by + halfBand)
        val pInner2 = toScreen(baseMax, by + halfBand)
        drawLine(lineColor.copy(alpha = 0.75f), pOuter1, pOuter2, strokeWidth = 2.4f * scale)
        drawLine(lineColor.copy(alpha = 0.75f), pInner1, pInner2, strokeWidth = 2.4f * scale)

        for (endX in listOf(baseMin, baseMax)) {
            val endPos = toScreen(endX, by)
            drawCircle(color = accentColor.copy(alpha = 0.85f), radius = 16f * scale, center = endPos)
            drawCircle(
                color = lineColor.copy(alpha = 0.85f),
                radius = 16f * scale,
                center = endPos,
                style = Stroke(width = 2f * scale)
            )
            drawCircle(color = surfLight, radius = 5.5f * scale, center = endPos)
        }
    }

    // Vertical decorative baselines (Left & Right)
    for (bx in listOf(165f, 835f)) {
        val p1 = toScreen(bx - halfBand, baseMin)
        val p2 = toScreen(bx - halfBand, baseMax)
        val p3 = toScreen(bx + halfBand, baseMin)
        val p4 = toScreen(bx + halfBand, baseMax)
        drawLine(lineColor.copy(alpha = 0.45f), p1, p2, strokeWidth = 1.8f * scale)
        drawLine(lineColor.copy(alpha = 0.45f), p3, p4, strokeWidth = 1.8f * scale)
        for (endY in listOf(baseMin, baseMax)) {
            val endPos = toScreen(bx, endY)
            drawCircle(color = accentColor.copy(alpha = 0.45f), radius = 14f * scale, center = endPos)
            drawCircle(
                color = lineColor.copy(alpha = 0.45f),
                radius = 14f * scale,
                center = endPos,
                style = Stroke(width = 1.6f * scale)
            )
        }
    }

    // Diagonal Foul Arrows pointing toward pockets
    val arrowPairs = listOf(
        Offset(280f, 280f) to Offset(125f, 125f),
        Offset(720f, 280f) to Offset(875f, 125f),
        Offset(280f, 720f) to Offset(125f, 875f),
        Offset(720f, 720f) to Offset(875f, 875f)
    )
    for ((fromC, toC) in arrowPairs) {
        val p1 = toScreen(fromC.x, fromC.y)
        val p2 = toScreen(toC.x, toC.y)
        drawLine(
            color = lineColor.copy(alpha = 0.52f),
            start = p1,
            end = p2,
            strokeWidth = 2f * scale,
            cap = StrokeCap.Round
        )
        // Curved decorative arc near arrow base
        drawCircle(
            color = lineColor.copy(alpha = 0.45f),
            radius = 22f * scale,
            center = p1,
            style = Stroke(width = 1.6f * scale)
        )
    }
}

private fun DrawScope.drawCoin(
    disc: DiscState,
    scale: Float,
    toScreen: (Float, Float) -> Offset
) {
    val drawX = if (disc.pocketed) {
        disc.x + (disc.pocketX - disc.x) * disc.sinkProgress
    } else disc.x
    val drawY = if (disc.pocketed) {
        disc.y + (disc.pocketY - disc.y) * disc.sinkProgress
    } else disc.y

    val shrink = if (disc.pocketed) (1f - disc.sinkProgress * 0.72f).coerceAtLeast(0.25f) else 1f
    val alpha = if (disc.pocketed) (1f - disc.sinkProgress).coerceIn(0f, 1f) else 1f
    val center = toScreen(drawX, drawY)
    val radius = CarromPhysics.COIN_RADIUS * scale * shrink

    // Soft drop shadow
    drawCircle(
        color = Color.Black.copy(alpha = 0.30f * alpha),
        radius = radius * 1.02f,
        center = Offset(center.x + 3f * scale, center.y + 4f * scale)
    )

    val (mainColor, rimColor, ringColor) = when (disc.type) {
        DiscType.WHITE -> Triple(
            Color(0xFFF9EFE0).copy(alpha = alpha),
            Color(0xFFCBB18B).copy(alpha = alpha),
            Color(0xFFD9C3A3).copy(alpha = alpha)
        )
        DiscType.BLACK -> Triple(
            Color(0xFF282220).copy(alpha = alpha),
            Color(0xFF141110).copy(alpha = alpha),
            Color(0xFF4C423E).copy(alpha = alpha)
        )
        DiscType.QUEEN -> Triple(
            Color(0xFFD93829).copy(alpha = alpha),
            Color(0xFF8C1910).copy(alpha = alpha),
            Color(0xFFFFD54F).copy(alpha = alpha)
        )
        DiscType.STRIKER -> Triple(Color.White, Color.Gray, Color.Yellow)
    }

    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(mainColor, rimColor),
            center = Offset(center.x - radius * 0.25f, center.y - radius * 0.25f),
            radius = radius * 1.2f
        ),
        radius = radius,
        center = center
    )

    // Turned-wood concentric rings
    drawCircle(
        color = ringColor,
        radius = radius * 0.72f,
        center = center,
        style = Stroke(width = 1.6f * scale)
    )
    drawCircle(
        color = ringColor.copy(alpha = 0.7f * alpha),
        radius = radius * 0.36f,
        center = center,
        style = Stroke(width = 1.4f * scale)
    )

    if (disc.type == DiscType.QUEEN) {
        drawCircle(
            color = Color(0xFFFFE082).copy(alpha = 0.9f * alpha),
            radius = radius * 0.16f,
            center = center
        )
    }
}

private fun DrawScope.drawStriker(
    striker: DiscState,
    style: StrikerStyle,
    isActiveTurn: Boolean,
    isValidPlacement: Boolean,
    canInteract: Boolean,
    scale: Float,
    toScreen: (Float, Float) -> Offset
) {
    val shrink = if (striker.pocketed) (1f - striker.sinkProgress * 0.72f).coerceAtLeast(0.25f) else 1f
    val alpha = if (striker.pocketed) (1f - striker.sinkProgress).coerceIn(0f, 1f) else 1f
    val center = toScreen(striker.x, striker.y)
    val radius = CarromPhysics.STRIKER_RADIUS * scale * shrink

    // Invalid placement warning halo or active turn glow
    if (isActiveTurn && !striker.pocketed) {
        val haloColor = when {
            !isValidPlacement -> Color(0xFFD93829).copy(alpha = 0.45f)
            canInteract -> Color(0xFF4CD995).copy(alpha = 0.30f)
            else -> Color(0xFFF2B705).copy(alpha = 0.22f)
        }
        drawCircle(
            color = haloColor,
            radius = radius * 1.38f,
            center = center
        )
    }

    // Drop shadow
    drawCircle(
        color = Color.Black.copy(alpha = 0.35f * alpha),
        radius = radius,
        center = Offset(center.x + 3.5f * scale, center.y + 5f * scale)
    )

    val coreColor = if (!isValidPlacement && isActiveTurn) {
        Color(0xFFFFCDD2)
    } else {
        Color(style.coreHex).copy(alpha = alpha)
    }
    val ringColor = if (!isValidPlacement && isActiveTurn) {
        Color(0xFFD93829)
    } else {
        Color(style.ringHex).copy(alpha = alpha)
    }
    val innerColor = Color(style.innerHex).copy(alpha = alpha)

    drawCircle(color = coreColor, radius = radius, center = center)
    drawCircle(
        color = ringColor,
        radius = radius * 0.88f,
        center = center,
        style = Stroke(width = 3.2f * scale)
    )
    drawCircle(
        color = innerColor,
        radius = radius * 0.52f,
        center = center,
        style = Stroke(width = 2.0f * scale)
    )
    drawCircle(color = ringColor, radius = radius * 0.20f, center = center)
}

private fun DrawScope.drawAimOverlay(
    striker: DiscState,
    aim: AimState,
    discs: List<DiscState>,
    placementValid: Boolean,
    scale: Float,
    toScreen: (Float, Float) -> Offset,
    isRotated: Boolean
) {
    val pullDist = hypot(aim.pullDx, aim.pullDy)
    if (pullDist < CarromPhysics.MIN_PULL_DISTANCE) return

    val power = ((pullDist - CarromPhysics.MIN_PULL_DISTANCE) /
        (CarromPhysics.MAX_PULL_DISTANCE - CarromPhysics.MIN_PULL_DISTANCE)).coerceIn(0f, 1f)

    val powerColor = when {
        !placementValid -> Color(0xFFD93829)
        power < 0.45f -> Color(0xFF4CD995)
        power < 0.8f -> Color(0xFFF2B705)
        else -> Color(0xFFFF5252)
    }

    val strikerScreen = toScreen(striker.x, striker.y)
    val pullRingRadius = min(pullDist, CarromPhysics.MAX_PULL_DISTANCE) * scale

    // Power pull-back ring around striker
    drawCircle(
        color = powerColor.copy(alpha = 0.20f),
        radius = pullRingRadius,
        center = strikerScreen
    )
    drawCircle(
        color = powerColor.copy(alpha = 0.85f),
        radius = pullRingRadius,
        center = strikerScreen,
        style = Stroke(width = 2.6f * scale)
    )

    // Pull handle line
    val pullEnd = toScreen(striker.x + aim.pullDx, striker.y + aim.pullDy)
    drawLine(
        color = powerColor.copy(alpha = 0.7f),
        start = strikerScreen,
        end = pullEnd,
        strokeWidth = 3f * scale,
        cap = StrokeCap.Round
    )
    drawCircle(
        color = powerColor,
        radius = 8f * scale,
        center = pullEnd
    )

    // Forward raycast prediction with ghost ball impact & coin deflection stub
    if (placementValid) {
        val prediction = CarromPhysics.predictAimRay(
            strikerX = striker.x,
            strikerY = striker.y,
            pullDx = aim.pullDx,
            pullDy = aim.pullDy,
            discs = discs
        )
        val dirX = -aim.pullDx / pullDist
        val dirY = -aim.pullDy / pullDist
        val rayEnd = if (prediction != null) {
            toScreen(prediction.hitX, prediction.hitY)
        } else {
            toScreen(striker.x + dirX * 520f, striker.y + dirY * 520f)
        }

        drawLine(
            color = powerColor.copy(alpha = 0.92f),
            start = strikerScreen,
            end = rayEnd,
            strokeWidth = 3.2f * scale,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f * scale, 10f * scale), 0f),
            cap = StrokeCap.Round
        )

        if (prediction != null && prediction.hitCoinId != null) {
            // Ghost striker impact circle
            drawCircle(
                color = powerColor.copy(alpha = 0.55f),
                radius = CarromPhysics.STRIKER_RADIUS * scale,
                center = rayEnd,
                style = Stroke(width = 2f * scale)
            )
            // Target coin deflection preview ray
            val defX = prediction.targetDeflectX
            val defY = prediction.targetDeflectY
            val coinCenter = toScreen(
                prediction.hitX + defX * (CarromPhysics.STRIKER_RADIUS + CarromPhysics.COIN_RADIUS),
                prediction.hitY + defY * (CarromPhysics.STRIKER_RADIUS + CarromPhysics.COIN_RADIUS)
            )
            val defEnd = toScreen(
                prediction.hitX + defX * (CarromPhysics.STRIKER_RADIUS + CarromPhysics.COIN_RADIUS + 115f),
                prediction.hitY + defY * (CarromPhysics.STRIKER_RADIUS + CarromPhysics.COIN_RADIUS + 115f)
            )
            drawLine(
                color = Color.White.copy(alpha = 0.85f),
                start = coinCenter,
                end = defEnd,
                strokeWidth = 2.6f * scale,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f * scale, 8f * scale), 0f),
                cap = StrokeCap.Round
            )
        } else {
            // Arrowhead tip when aiming at open board/wall
            val screenDirX = if (isRotated) -dirX else dirX
            val screenDirY = if (isRotated) -dirY else dirY
            val tipLen = 14f * scale
            val perpX = -screenDirY
            val perpY = screenDirX
            drawLine(
                color = powerColor,
                start = rayEnd,
                end = Offset(
                    rayEnd.x - screenDirX * tipLen + perpX * tipLen * 0.55f,
                    rayEnd.y - screenDirY * tipLen + perpY * tipLen * 0.55f
                ),
                strokeWidth = 3f * scale,
                cap = StrokeCap.Round
            )
            drawLine(
                color = powerColor,
                start = rayEnd,
                end = Offset(
                    rayEnd.x - screenDirX * tipLen - perpX * tipLen * 0.55f,
                    rayEnd.y - screenDirY * tipLen - perpY * tipLen * 0.55f
                ),
                strokeWidth = 3f * scale,
                cap = StrokeCap.Round
            )
        }
    }
}
