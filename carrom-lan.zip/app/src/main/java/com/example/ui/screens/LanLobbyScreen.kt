package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material.icons.rounded.Lan
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Router
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiTethering
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.DiscoveredRoom
import com.example.model.GameMode
import com.example.model.LanConnectionRole
import com.example.model.LanLobbyState
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.EmeraldOnline
import com.example.ui.theme.SkyLan

@Composable
fun LanLobbyScreen(
    lobbyState: LanLobbyState,
    localPlayerName: String,
    onSwitchToHost: () -> Unit,
    onSwitchToJoin: () -> Unit,
    onRefreshNetwork: () -> Unit,
    onSelectMode: (GameMode) -> Unit,
    onJoinRoom: (DiscoveredRoom) -> Unit,
    onJoinByIp: (String) -> Unit,
    onToggleReady: () -> Unit,
    onStartMatch: () -> Unit,
    onSendChat: (String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val isHostTab = lobbyState.role == LanConnectionRole.HOSTING ||
        lobbyState.role == LanConnectionRole.CONNECTED_AS_HOST

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.background,
                        MaterialTheme.colorScheme.surface
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp)
                .align(Alignment.TopCenter)
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("lobby_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back to Home"
                        )
                    }
                    Column {
                        Text(
                            text = "LAN Multiplayer Lobby",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Hotspot & Wi-Fi Direct TCP",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldGlow
                        )
                    }
                }

                if (lobbyState.pingMs > 0) {
                    Surface(
                        color = EmeraldOnline.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = "${lobbyState.pingMs} ms",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldGlow,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            // Tab Switcher (only switchable before peer joins or disconnect resets)
            if (lobbyState.role == LanConnectionRole.HOSTING || lobbyState.role == LanConnectionRole.JOINING) {
                SingleChoiceSegmentedButtonRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 4.dp)
                ) {
                    SegmentedButton(
                        selected = isHostTab,
                        onClick = onSwitchToHost,
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                        modifier = Modifier.testTag("tab_host_room")
                    ) {
                        Text("Host Room")
                    }
                    SegmentedButton(
                        selected = !isHostTab,
                        onClick = onSwitchToJoin,
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                        modifier = Modifier.testTag("tab_join_room")
                    ) {
                        Text("Join Room")
                    }
                }
            }

            // Error Banner if any
            if (!lobbyState.errorMessage.isNullOrBlank()) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 6.dp),
                    color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary),
                    shape = MaterialTheme.shapes.small
                ) {
                    Text(
                        text = lobbyState.errorMessage,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            when (lobbyState.role) {
                LanConnectionRole.HOSTING,
                LanConnectionRole.CONNECTED_AS_HOST -> {
                    HostLobbyContent(
                        lobbyState = lobbyState,
                        localPlayerName = localPlayerName,
                        onRefreshNetwork = onRefreshNetwork,
                        onSelectMode = onSelectMode,
                        onStartMatch = onStartMatch,
                        onSendChat = onSendChat
                    )
                }

                LanConnectionRole.JOINING -> {
                    JoinScannerContent(
                        lobbyState = lobbyState,
                        onRefresh = onSwitchToJoin,
                        onJoinRoom = onJoinRoom,
                        onJoinByIp = onJoinByIp
                    )
                }

                LanConnectionRole.CONNECTED_AS_CLIENT -> {
                    ClientConnectedLobbyContent(
                        lobbyState = lobbyState,
                        localPlayerName = localPlayerName,
                        onToggleReady = onToggleReady,
                        onSendChat = onSendChat
                    )
                }

                LanConnectionRole.NONE -> Unit
            }
        }
    }
}

@Composable
private fun HostLobbyContent(
    lobbyState: LanLobbyState,
    localPlayerName: String,
    onRefreshNetwork: () -> Unit,
    onSelectMode: (GameMode) -> Unit,
    onStartMatch: () -> Unit,
    onSendChat: (String) -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var copiedIp by remember { mutableStateOf(false) }
    val primaryIp = lobbyState.localIps.firstOrNull() ?: "192.168.43.1"

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hotspot / Wi-Fi IP Card
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.WifiTethering,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Room Active • Port 45454",
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        IconButton(onClick = onRefreshNetwork) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = "Refresh local IP"
                            )
                        }
                    }

                    Text(
                        text = "Turn on Mobile Hotspot (or connect to same Wi-Fi). Your friend will see your room automatically, or can enter IP:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.background,
                            shape = MaterialTheme.shapes.small,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = if (lobbyState.localIps.isEmpty()) {
                                    "Waiting for Hotspot / Wi-Fi..."
                                } else {
                                    lobbyState.localIps.joinToString("  •  ")
                                },
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                clipboard.setText(AnnotatedString(primaryIp))
                                copiedIp = true
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ContentCopy,
                                contentDescription = "Copy IP",
                                tint = if (copiedIp) EmeraldGlow else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // Game Mode Selector
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Match Mode",
                    style = MaterialTheme.typography.titleMedium
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(GameMode.entries) { mode ->
                        FilterChip(
                            selected = lobbyState.selectedMode == mode,
                            onClick = { onSelectMode(mode) },
                            label = { Text(mode.title) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }
                Text(
                    text = lobbyState.selectedMode.subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // 2-Player Roster
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Players (${if (lobbyState.guestName != null) "2/2" else "1/2"})",
                    style = MaterialTheme.typography.titleMedium
                )

                PlayerSlotCard(
                    name = lobbyState.hostName.ifBlank { localPlayerName },
                    roleLabel = "HOST • White Coins",
                    isReady = true,
                    isWaiting = false
                )

                if (lobbyState.guestName != null) {
                    PlayerSlotCard(
                        name = lobbyState.guestName,
                        roleLabel = "FRIEND • Black Coins",
                        isReady = lobbyState.guestReady,
                        isWaiting = false
                    )
                } else {
                    WaitingForFriendCard()
                }
            }
        }

        // Lobby Chat & Start Button
        item {
            LobbyChatSection(
                lobbyState = lobbyState,
                onSendChat = onSendChat
            )
        }

        item {
            val canStart = lobbyState.guestName != null
            Button(
                onClick = onStartMatch,
                enabled = canStart,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 54.dp)
                    .testTag("start_lan_match_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldOnline,
                    contentColor = MaterialTheme.colorScheme.onSecondary
                ),
                shape = MaterialTheme.shapes.medium
            ) {
                Icon(imageVector = Icons.Rounded.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = when {
                        lobbyState.guestName == null -> "Waiting for Friend to Join..."
                        !lobbyState.guestReady -> "Start Match (Friend Not Ready Yet)"
                        else -> "START MATCH"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun JoinScannerContent(
    lobbyState: LanLobbyState,
    onRefresh: () -> Unit,
    onJoinRoom: (DiscoveredRoom) -> Unit,
    onJoinByIp: (String) -> Unit
) {
    var manualIp by remember(lobbyState.suggestedHostIp) { mutableStateOf(lobbyState.suggestedHostIp) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Discovered Rooms Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ScanningPulseIcon()
                    Column {
                        Text(
                            text = "Nearby LAN Rooms",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "Scanning Hotspot & Wi-Fi...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SkyLan
                        )
                    }
                }
                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier.testTag("rescan_rooms_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = "Rescan LAN rooms"
                    )
                }
            }
        }

        if (lobbyState.discoveredRooms.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Wifi,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = "No rooms found yet",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "Connect to your friend's Hotspot or same Wi-Fi, ask them to tap 'Host Room', or use Direct IP below.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(lobbyState.discoveredRooms, key = { it.roomId }) { room ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.medium)
                        .clickable { onJoinRoom(room) }
                        .testTag("room_card_${room.roomId}"),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = BorderStroke(1.dp, SkyLan.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(SkyLan.copy(alpha = 0.16f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Lan,
                                    contentDescription = null,
                                    tint = SkyLan
                                )
                            }
                            Column {
                                Text(
                                    text = "${room.hostName}'s Table",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = "${room.mode.title} • ${room.hostIp}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Button(
                            onClick = { onJoinRoom(room) },
                            colors = ButtonDefaults.buttonColors(containerColor = SkyLan),
                            modifier = Modifier.heightIn(min = 42.dp)
                        ) {
                            Text("Join")
                        }
                    }
                }
            }
        }

        // Direct IP Fallback (Essential for OEM Hotspots)
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Router,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Direct Hotspot / IP Connect",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    Text(
                        text = "Auto-detected Hotspot Gateway IP is pre-filled. Tap Connect or type your friend's shown IP.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = manualIp,
                            onValueChange = { manualIp = it },
                            label = { Text("Host IP") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("direct_ip_input")
                        )
                        Button(
                            onClick = { onJoinByIp(manualIp) },
                            modifier = Modifier
                                .heightIn(min = 52.dp)
                                .testTag("direct_ip_connect_button")
                        ) {
                            Text("Connect")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ClientConnectedLobbyContent(
    lobbyState: LanLobbyState,
    localPlayerName: String,
    onToggleReady: () -> Unit,
    onSendChat: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, EmeraldGlow.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Connected to ${lobbyState.hostName}'s Room",
                        style = MaterialTheme.typography.titleLarge,
                        color = EmeraldGlow
                    )
                    Text(
                        text = "Mode: ${lobbyState.selectedMode.title} • ${lobbyState.selectedMode.subtitle}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PlayerSlotCard(
                    name = lobbyState.hostName,
                    roleLabel = "HOST • White Coins",
                    isReady = true,
                    isWaiting = false
                )
                PlayerSlotCard(
                    name = localPlayerName,
                    roleLabel = "YOU • Black Coins",
                    isReady = lobbyState.guestReady,
                    isWaiting = false
                )
            }
        }

        item {
            LobbyChatSection(lobbyState = lobbyState, onSendChat = onSendChat)
        }

        item {
            Button(
                onClick = onToggleReady,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 54.dp)
                    .testTag("client_ready_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (lobbyState.guestReady) {
                        MaterialTheme.colorScheme.primaryContainer
                    } else {
                        EmeraldOnline
                    },
                    contentColor = if (lobbyState.guestReady) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onSecondary
                    }
                ),
                shape = MaterialTheme.shapes.medium
            ) {
                Icon(
                    imageVector = Icons.Rounded.CheckCircle,
                    contentDescription = null
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = if (lobbyState.guestReady) "READY! (Waiting for Host to Start)" else "TAP WHEN READY",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun PlayerSlotCard(
    name: String,
    roleLabel: String,
    isReady: Boolean,
    isWaiting: Boolean
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(
            1.dp,
            if (isReady) EmeraldGlow.copy(alpha = 0.6f) else MaterialTheme.colorScheme.outline
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = name,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = roleLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Surface(
                color = if (isReady) EmeraldOnline.copy(alpha = 0.22f) else MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(50)
            ) {
                Text(
                    text = if (isReady) "READY" else if (isWaiting) "WAITING" else "NOT READY",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isReady) EmeraldGlow else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }
}

@Composable
private fun WaitingForFriendCard() {
    val transition = rememberInfiniteTransition(label = "waitPulse")
    val alpha by transition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "waitAlpha"
    )
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.HourglassTop,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Column {
                Text(
                    text = "Waiting for Friend...",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "Friend taps 'Join Room' on Hotspot / Wi-Fi",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun ScanningPulseIcon() {
    val transition = rememberInfiniteTransition(label = "scanPulse")
    val scale by transition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "scanScale"
    )
    Box(
        modifier = Modifier
            .size(38.dp)
            .scale(scale)
            .clip(CircleShape)
            .background(SkyLan.copy(alpha = 0.18f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Rounded.Wifi,
            contentDescription = null,
            tint = SkyLan
        )
    }
}

@Composable
private fun LobbyChatSection(
    lobbyState: LanLobbyState,
    onSendChat: (String) -> Unit
) {
    var draft by remember { mutableStateOf("") }
    val quickChats = listOf("Let's play!", "Ready?", "Classic Queen?", "Join via Hotspot")

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Lobby Chat",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(92.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                lobbyState.chatMessages.takeLast(4).forEach { msg ->
                    Text(
                        text = if (msg.isSystem) "• ${msg.text}" else "${msg.sender}: ${msg.text}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (msg.isSystem) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(quickChats) { qc ->
                    AssistChip(
                        onClick = { onSendChat(qc) },
                        label = { Text(qc, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    placeholder = { Text("Message friend...") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("lobby_chat_input")
                )
                IconButton(
                    onClick = {
                        if (draft.isNotBlank()) {
                            onSendChat(draft)
                            draft = ""
                        }
                    },
                    modifier = Modifier.testTag("lobby_chat_send")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Send,
                        contentDescription = "Send chat message",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}
