package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class CarromSoundEngine {
    private val sampleRate = 22050
    private val executor = Executors.newSingleThreadExecutor()

    @Volatile
    var soundEnabled: Boolean = true

    private val clackSoft = synthesizeClack(durationMs = 55, baseFreq = 980.0, decay = 58.0, gain = 0.45)
    private val clackHard = synthesizeClack(durationMs = 75, baseFreq = 1320.0, decay = 48.0, gain = 0.85)
    private val wallThud = synthesizeClack(durationMs = 65, baseFreq = 420.0, decay = 45.0, gain = 0.65)
    private val pocketDrop = synthesizeSweep(durationMs = 170, startFreq = 540.0, endFreq = 190.0, gain = 0.75)
    private val foulTone = synthesizeSweep(durationMs = 240, startFreq = 260.0, endFreq = 130.0, gain = 0.7)
    private val queenChime = synthesizeChord(durationMs = 360, freqs = doubleArrayOf(587.33, 880.0, 1174.66), gain = 0.65)
    private val winFanfare = synthesizeChord(durationMs = 520, freqs = doubleArrayOf(523.25, 659.25, 783.99, 1046.5), gain = 0.7)

    fun playStrike() {
        if (!soundEnabled) return
        playBuffer(clackHard)
    }

    fun playCoinHit(intensity: Float) {
        if (!soundEnabled) return
        if (intensity > 0.45f) {
            playBuffer(clackHard)
        } else if (intensity > 0.1f) {
            playBuffer(clackSoft)
        }
    }

    fun playWallBounce(intensity: Float) {
        if (!soundEnabled || intensity < 0.12f) return
        playBuffer(wallThud)
    }

    fun playPocket() {
        if (!soundEnabled) return
        playBuffer(pocketDrop)
    }

    fun playQueen() {
        if (!soundEnabled) return
        playBuffer(queenChime)
    }

    fun playFoul() {
        if (!soundEnabled) return
        playBuffer(foulTone)
    }

    fun playWin() {
        if (!soundEnabled) return
        playBuffer(winFanfare)
    }

    private fun playBuffer(pcm: ShortArray) {
        executor.execute {
            runCatching {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(pcm.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                track.write(pcm, 0, pcm.size)
                track.play()
                val sleepMs = (pcm.size * 1000L / sampleRate) + 40L
                Thread.sleep(sleepMs)
                track.release()
            }
        }
    }

    private fun synthesizeClack(
        durationMs: Int,
        baseFreq: Double,
        decay: Double,
        gain: Double
    ): ShortArray {
        val count = sampleRate * durationMs / 1000
        return ShortArray(count) { i ->
            val t = i.toDouble() / sampleRate
            val env = exp(-t * decay)
            val tone = sin(2.0 * PI * baseFreq * t) * 0.65 +
                sin(2.0 * PI * (baseFreq * 1.67) * t) * 0.35
            (tone * env * gain * Short.MAX_VALUE).toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
    }

    private fun synthesizeSweep(
        durationMs: Int,
        startFreq: Double,
        endFreq: Double,
        gain: Double
    ): ShortArray {
        val count = sampleRate * durationMs / 1000
        var phase = 0.0
        return ShortArray(count) { i ->
            val progress = i.toDouble() / count
            val freq = startFreq + (endFreq - startFreq) * progress
            phase += 2.0 * PI * freq / sampleRate
            val env = exp(-progress * 4.5)
            (sin(phase) * env * gain * Short.MAX_VALUE).toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
    }

    private fun synthesizeChord(
        durationMs: Int,
        freqs: DoubleArray,
        gain: Double
    ): ShortArray {
        val count = sampleRate * durationMs / 1000
        return ShortArray(count) { i ->
            val t = i.toDouble() / sampleRate
            val progress = i.toDouble() / count
            val env = exp(-progress * 3.8)
            var sum = 0.0
            for (f in freqs) {
                sum += sin(2.0 * PI * f * t)
            }
            val avg = sum / freqs.size
            (avg * env * gain * Short.MAX_VALUE).toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
    }

    fun release() {
        executor.shutdownNow()
    }
}
