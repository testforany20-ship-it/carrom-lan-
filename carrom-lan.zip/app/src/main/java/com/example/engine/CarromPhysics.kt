package com.example.engine

import com.example.model.DiscState
import com.example.model.DiscType
import com.example.model.GameMode
import com.example.model.MatchState
import com.example.model.PlayerSeat
import com.example.model.QueenState
import com.example.model.TurnPhase
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

object CarromPhysics {
    const val BOARD_SIZE = 1000f
    const val PLAY_MIN = 38f
    const val PLAY_MAX = 962f

    const val COIN_RADIUS = 22f
    const val STRIKER_RADIUS = 30f
    const val POCKET_RADIUS = 41f
    const val CAPTURE_RADIUS = 34f

    const val BASELINE_P1_Y = 835f
    const val BASELINE_P2_Y = 165f
    const val BASELINE_MIN_X = 185f
    const val BASELINE_MAX_X = 815f

    const val COIN_MASS = 1.0f
    const val STRIKER_MASS = 2.4f

    const val MAX_PULL_DISTANCE = 175f
    const val MIN_PULL_DISTANCE = 18f
    const val MAX_SHOT_SPEED = 2250f

    val POCKET_CENTERS = listOf(
        56f to 56f,
        944f to 56f,
        56f to 944f,
        944f to 944f
    )

    data class AimPrediction(
        val hitX: Float,
        val hitY: Float,
        val hitCoinId: Int?,
        val targetDeflectX: Float = 0f,
        val targetDeflectY: Float = 0f
    )

    data class StepEvents(
        val maxCoinImpact: Float = 0f,
        val maxWallImpact: Float = 0f,
        val pocketedDiscs: List<DiscType> = emptyList(),
        val allStopped: Boolean = false
    )

    fun createInitialDiscs(mode: GameMode): List<DiscState> {
        val discs = mutableListOf<DiscState>()
        val cx = 500f
        val cy = 500f
        val d = COIN_RADIUS * 2.04f
        var idCounter = 1

        if (mode != GameMode.DISC_POOL) {
            // Queen at exact center
            discs += DiscState(id = 0, type = DiscType.QUEEN, x = cx, y = cy)
        }

        // Inner ring of 6 coins
        for (i in 0 until 6) {
            val angle = -PI / 2.0 + i * (PI / 3.0)
            val x = cx + (d * cos(angle)).toFloat()
            val y = cy + (d * sin(angle)).toFloat()
            val type = if (i % 2 == 0) DiscType.WHITE else DiscType.BLACK
            discs += DiscState(id = idCounter++, type = type, x = x, y = y)
        }

        // Outer ring of 12 coins in classic Y-formation
        // 6 outer vertices at distance 2*d, and 6 edge midpoints at distance sqrt(3)*d
        for (i in 0 until 12) {
            val angle = -PI / 2.0 + i * (PI / 6.0)
            val dist = if (i % 2 == 0) d * 2.0f else d * sqrt(3.0).toFloat()
            val x = cx + (dist * cos(angle)).toFloat()
            val y = cy + (dist * sin(angle)).toFloat()
            // Ensure exactly 9 white and 9 black overall:
            // Inner ring already has 3 WHITE (i=0,2,4) and 3 BLACK (i=1,3,5).
            // Outer ring needs 6 WHITE and 6 BLACK:
            val type = if (i % 2 == 0) DiscType.WHITE else DiscType.BLACK
            discs += DiscState(id = idCounter++, type = type, x = x, y = y)
        }

        // In Disc Pool (no Queen), center is empty or place an extra neutral gap;
        // Wait: with 18 coins (9 White + 9 Black) around the empty center, it packs cleanly!
        return discs
    }

    fun baselineY(seat: PlayerSeat): Float =
        if (seat == PlayerSeat.PLAYER_1) BASELINE_P1_Y else BASELINE_P2_Y

    fun isStrikerPositionValid(x: Float, seat: PlayerSeat, discs: List<DiscState>): Boolean {
        val y = baselineY(seat)
        val minDist = STRIKER_RADIUS + COIN_RADIUS + 2f
        for (disc in discs) {
            if (disc.pocketed) continue
            val dx = disc.x - x
            val dy = disc.y - y
            if (dx * dx + dy * dy < minDist * minDist) {
                return false
            }
        }
        return true
    }

    fun findNearestValidStrikerX(preferredX: Float, seat: PlayerSeat, discs: List<DiscState>): Float {
        val clamped = preferredX.coerceIn(BASELINE_MIN_X, BASELINE_MAX_X)
        if (isStrikerPositionValid(clamped, seat, discs)) return clamped
        for (offset in 10..630 step 10) {
            val right = (clamped + offset).coerceIn(BASELINE_MIN_X, BASELINE_MAX_X)
            if (isStrikerPositionValid(right, seat, discs)) return right
            val left = (clamped - offset).coerceIn(BASELINE_MIN_X, BASELINE_MAX_X)
            if (isStrikerPositionValid(left, seat, discs)) return left
        }
        return clamped
    }

    fun createStrikerForTurn(seat: PlayerSeat, discs: List<DiscState>): DiscState {
        val validX = findNearestValidStrikerX(500f, seat, discs)
        return DiscState(
            id = 99,
            type = DiscType.STRIKER,
            x = validX,
            y = baselineY(seat)
        )
    }

    fun stepPhysics(
        dtSeconds: Float,
        discs: MutableList<DiscState>,
        striker: DiscState
    ): Pair<DiscState, StepEvents> {
        val subSteps = 5
        val subDt = dtSeconds.coerceIn(0.001f, 0.035f) / subSteps

        var currentStriker = striker
        var maxCoinImpact = 0f
        var maxWallImpact = 0f
        val newlyPocketed = mutableListOf<DiscType>()

        // Advance pocket sinking visual animation for already-pocketed coins
        for (i in discs.indices) {
            val d = discs[i]
            if (d.pocketed && d.sinkProgress < 1f) {
                discs[i] = d.copy(sinkProgress = (d.sinkProgress + dtSeconds * 5.2f).coerceAtMost(1f))
            }
        }
        if (currentStriker.pocketed && currentStriker.sinkProgress < 1f) {
            currentStriker = currentStriker.copy(
                sinkProgress = (currentStriker.sinkProgress + dtSeconds * 5.2f).coerceAtMost(1f)
            )
        }

        // Build unified mutable body list for sub-stepping (indices 0..n-1 = discs, index n = striker)
        val bodies = ArrayList<DiscState>(discs.size + 1)
        bodies.addAll(discs)
        bodies.add(currentStriker)
        val strikerIdx = bodies.lastIndex

        repeat(subSteps) {
            // 1. Integrate positions + boric powder friction
            val expDamp = exp(-1.38f * subDt)
            for (i in bodies.indices) {
                val b = bodies[i]
                if (b.pocketed) continue
                var nx = b.x + b.vx * subDt
                var ny = b.y + b.vy * subDt
                var nvx = b.vx * expDamp
                var nvy = b.vy * expDamp

                val speed = hypot(nvx, nvy)
                if (speed > 0f) {
                    val linearDrop = 140f * subDt
                    if (speed <= linearDrop || speed < 14f) {
                        nvx = 0f
                        nvy = 0f
                    } else {
                        val scale = (speed - linearDrop) / speed
                        nvx *= scale
                        nvy *= scale
                    }
                }

                // Pocket funneling & capture check
                var captured = false
                for ((px, py) in POCKET_CENTERS) {
                    val dx = px - nx
                    val dy = py - ny
                    val dist = hypot(dx, dy)
                    if (dist < CAPTURE_RADIUS) {
                        bodies[i] = b.copy(
                            x = px,
                            y = py,
                            vx = 0f,
                            vy = 0f,
                            pocketed = true,
                            sinkProgress = 0.05f,
                            pocketX = px,
                            pocketY = py
                        )
                        newlyPocketed += b.type
                        captured = true
                        break
                    } else if (dist < POCKET_RADIUS + 4f && dist > 0.001f) {
                        // Gentle pocket lip pull
                        val pull = 460f * subDt
                        nvx += (dx / dist) * pull
                        nvy += (dy / dist) * pull
                    }
                }
                if (captured) continue

                // Cushion wall collisions
                val r = if (b.type == DiscType.STRIKER) STRIKER_RADIUS else COIN_RADIUS
                val minCoord = PLAY_MIN + r
                val maxCoord = PLAY_MAX - r
                val wallRestitution = 0.82f

                // Skip wall rebound right at corner pocket mouths so angled shots drop cleanly
                val nearCornerMouth = POCKET_CENTERS.any { (px, py) ->
                    hypot(nx - px, ny - py) < POCKET_RADIUS + r * 0.65f
                }

                if (!nearCornerMouth) {
                    if (nx < minCoord) {
                        nx = minCoord
                        if (nvx < 0f) {
                            maxWallImpact = max(maxWallImpact, abs(nvx) / MAX_SHOT_SPEED)
                            nvx = -nvx * wallRestitution
                        }
                    } else if (nx > maxCoord) {
                        nx = maxCoord
                        if (nvx > 0f) {
                            maxWallImpact = max(maxWallImpact, abs(nvx) / MAX_SHOT_SPEED)
                            nvx = -nvx * wallRestitution
                        }
                    }

                    if (ny < minCoord) {
                        ny = minCoord
                        if (nvy < 0f) {
                            maxWallImpact = max(maxWallImpact, abs(nvy) / MAX_SHOT_SPEED)
                            nvy = -nvy * wallRestitution
                        }
                    } else if (ny > maxCoord) {
                        ny = maxCoord
                        if (nvy > 0f) {
                            maxWallImpact = max(maxWallImpact, abs(nvy) / MAX_SHOT_SPEED)
                            nvy = -nvy * wallRestitution
                        }
                    }
                } else {
                    // Hard outer frame clamp even near corners
                    nx = nx.coerceIn(PLAY_MIN + 10f, PLAY_MAX - 10f)
                    ny = ny.coerceIn(PLAY_MIN + 10f, PLAY_MAX - 10f)
                }

                bodies[i] = b.copy(x = nx, y = ny, vx = nvx, vy = nvy)
            }

            // 2. Pairwise elastic circle-circle collisions
            val restitution = 0.89f
            for (i in 0 until bodies.size) {
                val a = bodies[i]
                if (a.pocketed) continue
                val ra = if (a.type == DiscType.STRIKER) STRIKER_RADIUS else COIN_RADIUS
                val ma = if (a.type == DiscType.STRIKER) STRIKER_MASS else COIN_MASS

                for (j in i + 1 until bodies.size) {
                    val b = bodies[j]
                    if (b.pocketed) continue
                    val rb = if (b.type == DiscType.STRIKER) STRIKER_RADIUS else COIN_RADIUS
                    val mb = if (b.type == DiscType.STRIKER) STRIKER_MASS else COIN_MASS

                    val dx = b.x - a.x
                    val dy = b.y - a.y
                    val minDist = ra + rb
                    val distSq = dx * dx + dy * dy
                    if (distSq >= minDist * minDist) continue

                    val dist = sqrt(distSq).coerceAtLeast(0.0001f)
                    val nx = dx / dist
                    val ny = dy / dist

                    // Positional correction (prevent overlap sinking)
                    val overlap = minDist - dist
                    val totalInvMass = (1f / ma) + (1f / mb)
                    val corrA = overlap * (1f / ma) / totalInvMass
                    val corrB = overlap * (1f / mb) / totalInvMass

                    var ax = a.x - nx * corrA
                    var ay = a.y - ny * corrA
                    var bx = b.x + nx * corrB
                    var by = b.y + ny * corrB

                    // Keep separated bodies inside board
                    ax = ax.coerceIn(PLAY_MIN + ra * 0.5f, PLAY_MAX - ra * 0.5f)
                    ay = ay.coerceIn(PLAY_MIN + ra * 0.5f, PLAY_MAX - ra * 0.5f)
                    bx = bx.coerceIn(PLAY_MIN + rb * 0.5f, PLAY_MAX - rb * 0.5f)
                    by = by.coerceIn(PLAY_MIN + rb * 0.5f, PLAY_MAX - rb * 0.5f)

                    // Relative velocity along normal
                    val rvx = b.vx - a.vx
                    val rvy = b.vy - a.vy
                    val velAlongNormal = rvx * nx + rvy * ny

                    var avx = a.vx
                    var avy = a.vy
                    var bvx = b.vx
                    var bvy = b.vy

                    if (velAlongNormal < 0f) {
                        val impulse = -(1f + restitution) * velAlongNormal / totalInvMass
                        val ix = impulse * nx
                        val iy = impulse * ny
                        avx -= ix / ma
                        avy -= iy / ma
                        bvx += ix / mb
                        bvy += iy / mb

                        val impactNorm = (-velAlongNormal / MAX_SHOT_SPEED).coerceIn(0f, 1f)
                        if (impactNorm > maxCoinImpact) {
                            maxCoinImpact = impactNorm
                        }
                    }

                    bodies[i] = a.copy(x = ax, y = ay, vx = avx, vy = avy)
                    bodies[j] = b.copy(x = bx, y = by, vx = bvx, vy = bvy)
                }
            }
        }

        // Write back to discs and striker
        for (i in discs.indices) {
            discs[i] = bodies[i]
        }
        currentStriker = bodies[strikerIdx]

        val anyMoving = bodies.any { !it.pocketed && (it.vx != 0f || it.vy != 0f) }
        return currentStriker to StepEvents(
            maxCoinImpact = maxCoinImpact,
            maxWallImpact = maxWallImpact,
            pocketedDiscs = newlyPocketed,
            allStopped = !anyMoving
        )
    }

    fun evaluateTurnResult(
        previousState: MatchState,
        updatedDiscs: MutableList<DiscState>,
        pocketedThisTurn: List<DiscType>
    ): MatchState {
        val turn = previousState.currentTurn
        val mode = previousState.mode
        val strikerFouled = pocketedThisTurn.contains(DiscType.STRIKER)
        val queenPocketed = pocketedThisTurn.contains(DiscType.QUEEN)
        val whitePocketedCount = pocketedThisTurn.count { it == DiscType.WHITE }
        val blackPocketedCount = pocketedThisTurn.count { it == DiscType.BLACK }

        var queenState = previousState.queenState
        var p1Score = previousState.p1Score
        var p2Score = previousState.p2Score
        var nextTurn = if (turn == PlayerSeat.PLAYER_1) PlayerSeat.PLAYER_2 else PlayerSeat.PLAYER_1
        var banner = ""

        val myCoinType = if (turn == PlayerSeat.PLAYER_1) DiscType.WHITE else DiscType.BLACK
        val myPocketedNow = if (turn == PlayerSeat.PLAYER_1) whitePocketedCount else blackPocketedCount

        if (mode == GameMode.POINTS_29) {
            // Points Blitz: White = 2, Black = 1, Queen = 5 (covered)
            val turnPoints = whitePocketedCount * 2 + blackPocketedCount * 1
            if (turn == PlayerSeat.PLAYER_1) p1Score += turnPoints else p2Score += turnPoints

            // Check previous queen cover requirement
            if (queenState == QueenState.NEEDS_COVER_P1 && turn == PlayerSeat.PLAYER_1) {
                if (!strikerFouled && (whitePocketedCount + blackPocketedCount) > 0) {
                    queenState = QueenState.COVERED_P1
                    p1Score += 5
                    banner = "${previousState.player1Name} covered the Queen! +5 pts"
                } else {
                    returnDiscToCenter(updatedDiscs, DiscType.QUEEN)
                    queenState = QueenState.ON_BOARD
                    banner = "Queen uncovered — returned to center!"
                }
            } else if (queenState == QueenState.NEEDS_COVER_P2 && turn == PlayerSeat.PLAYER_2) {
                if (!strikerFouled && (whitePocketedCount + blackPocketedCount) > 0) {
                    queenState = QueenState.COVERED_P2
                    p2Score += 5
                    banner = "${previousState.player2Name} covered the Queen! +5 pts"
                } else {
                    returnDiscToCenter(updatedDiscs, DiscType.QUEEN)
                    queenState = QueenState.ON_BOARD
                    banner = "Queen uncovered — returned to center!"
                }
            }

            if (strikerFouled) {
                if (queenPocketed) {
                    returnDiscToCenter(updatedDiscs, DiscType.QUEEN)
                    queenState = QueenState.ON_BOARD
                }
                if (turn == PlayerSeat.PLAYER_1) {
                    p1Score = max(0, p1Score - 2)
                } else {
                    p2Score = max(0, p2Score - 2)
                }
                banner = "Striker Foul! -2 pts penalty"
            } else {
                if (queenPocketed) {
                    if (whitePocketedCount + blackPocketedCount > 0) {
                        queenState = if (turn == PlayerSeat.PLAYER_1) QueenState.COVERED_P1 else QueenState.COVERED_P2
                        if (turn == PlayerSeat.PLAYER_1) p1Score += 5 else p2Score += 5
                        banner = "Queen pocketed & covered! +5 pts"
                    } else {
                        queenState = if (turn == PlayerSeat.PLAYER_1) QueenState.NEEDS_COVER_P1 else QueenState.NEEDS_COVER_P2
                        banner = "Queen pocketed! Sink any coin to cover"
                    }
                    nextTurn = turn
                } else if (whitePocketedCount + blackPocketedCount > 0) {
                    nextTurn = turn
                    if (banner.isEmpty()) banner = "Nice shot! +$turnPoints pts, shoot again"
                } else if (banner.isEmpty()) {
                    banner = "${if (nextTurn == PlayerSeat.PLAYER_1) previousState.player1Name else previousState.player2Name}'s turn"
                }
            }

            val remainingCoins = updatedDiscs.count { !it.pocketed && it.type != DiscType.QUEEN }
            val queenCleared = queenState == QueenState.COVERED_P1 || queenState == QueenState.COVERED_P2 ||
                updatedDiscs.none { !it.pocketed && it.type == DiscType.QUEEN }
            if (remainingCoins == 0 && queenCleared) {
                val winner = if (p1Score >= p2Score) PlayerSeat.PLAYER_1 else PlayerSeat.PLAYER_2
                val winName = if (winner == PlayerSeat.PLAYER_1) previousState.player1Name else previousState.player2Name
                return previousState.copy(
                    discs = updatedDiscs.toList(),
                    striker = createStrikerForTurn(winner, updatedDiscs),
                    queenState = queenState,
                    p1Score = p1Score,
                    p2Score = p2Score,
                    p1PocketedCount = updatedDiscs.count { it.pocketed && it.type == DiscType.WHITE },
                    p2PocketedCount = updatedDiscs.count { it.pocketed && it.type == DiscType.BLACK },
                    phase = TurnPhase.MATCH_OVER,
                    winner = winner,
                    winReason = "$winName wins $p1Score - $p2Score!",
                    statusBanner = "$winName wins the Blitz!"
                )
            }
        } else {
            // CLASSIC_QUEEN or DISC_POOL
            val activeName = if (turn == PlayerSeat.PLAYER_1) previousState.player1Name else previousState.player2Name

            // Resolve pending Queen cover first
            if (mode == GameMode.CLASSIC_QUEEN) {
                if (queenState == QueenState.NEEDS_COVER_P1 && turn == PlayerSeat.PLAYER_1) {
                    if (!strikerFouled && whitePocketedCount > 0) {
                        queenState = QueenState.COVERED_P1
                        banner = "$activeName covered the Queen!"
                    } else {
                        returnDiscToCenter(updatedDiscs, DiscType.QUEEN)
                        queenState = QueenState.ON_BOARD
                        banner = "Queen not covered — returned to center"
                    }
                } else if (queenState == QueenState.NEEDS_COVER_P2 && turn == PlayerSeat.PLAYER_2) {
                    if (!strikerFouled && blackPocketedCount > 0) {
                        queenState = QueenState.COVERED_P2
                        banner = "$activeName covered the Queen!"
                    } else {
                        returnDiscToCenter(updatedDiscs, DiscType.QUEEN)
                        queenState = QueenState.ON_BOARD
                        banner = "Queen not covered — returned to center"
                    }
                }
            }

            if (strikerFouled) {
                if (queenPocketed && mode == GameMode.CLASSIC_QUEEN) {
                    returnDiscToCenter(updatedDiscs, DiscType.QUEEN)
                    queenState = QueenState.ON_BOARD
                }
                val returned = returnDiscToCenter(updatedDiscs, myCoinType)
                banner = if (returned) {
                    "Striker Foul! $activeName returns 1 coin"
                } else {
                    "Striker Foul! Turn passes"
                }
                nextTurn = if (turn == PlayerSeat.PLAYER_1) PlayerSeat.PLAYER_2 else PlayerSeat.PLAYER_1
            } else {
                var keepTurn = myPocketedNow > 0

                if (mode == GameMode.CLASSIC_QUEEN && queenPocketed) {
                    if (myPocketedNow > 0) {
                        queenState = if (turn == PlayerSeat.PLAYER_1) QueenState.COVERED_P1 else QueenState.COVERED_P2
                        banner = "$activeName pocketed & covered the Queen!"
                        keepTurn = true
                    } else {
                        queenState = if (turn == PlayerSeat.PLAYER_1) QueenState.NEEDS_COVER_P1 else QueenState.NEEDS_COVER_P2
                        banner = "Queen pocketed! Sink a coin to cover"
                        keepTurn = true
                    }
                }

                // In Classic Queen, cannot win while Queen is still on board:
                if (mode == GameMode.CLASSIC_QUEEN && queenState == QueenState.ON_BOARD) {
                    val whiteLeftCheck = updatedDiscs.count { !it.pocketed && it.type == DiscType.WHITE }
                    val blackLeftCheck = updatedDiscs.count { !it.pocketed && it.type == DiscType.BLACK }
                    if (whiteLeftCheck == 0 && turn == PlayerSeat.PLAYER_1) {
                        returnDiscToCenter(updatedDiscs, DiscType.WHITE)
                        banner = "Sink & cover the Queen before your final coin!"
                        keepTurn = false
                    } else if (blackLeftCheck == 0 && turn == PlayerSeat.PLAYER_2) {
                        returnDiscToCenter(updatedDiscs, DiscType.BLACK)
                        banner = "Sink & cover the Queen before your final coin!"
                        keepTurn = false
                    }
                }

                nextTurn = if (keepTurn) turn else if (turn == PlayerSeat.PLAYER_1) PlayerSeat.PLAYER_2 else PlayerSeat.PLAYER_1

                if (banner.isEmpty()) {
                    banner = when {
                        keepTurn && myPocketedNow > 0 -> "$activeName sunk $myPocketedNow! Shoot again"
                        else -> "${if (nextTurn == PlayerSeat.PLAYER_1) previousState.player1Name else previousState.player2Name}'s turn"
                    }
                }
            }

            val whiteLeft = updatedDiscs.count { !it.pocketed && it.type == DiscType.WHITE }
            val blackLeft = updatedDiscs.count { !it.pocketed && it.type == DiscType.BLACK }
            val whitePocketedTotal = 9 - whiteLeft
            val blackPocketedTotal = 9 - blackLeft

            p1Score = whitePocketedTotal + if (queenState == QueenState.COVERED_P1) 3 else 0
            p2Score = blackPocketedTotal + if (queenState == QueenState.COVERED_P2) 3 else 0

            val queenSettled = mode != GameMode.CLASSIC_QUEEN ||
                (queenState == QueenState.COVERED_P1 || queenState == QueenState.COVERED_P2 || queenState == QueenState.ON_BOARD)

            if (whiteLeft == 0 && queenSettled && queenState != QueenState.NEEDS_COVER_P1) {
                return previousState.copy(
                    discs = updatedDiscs.toList(),
                    striker = createStrikerForTurn(PlayerSeat.PLAYER_1, updatedDiscs),
                    queenState = queenState,
                    p1Score = p1Score,
                    p2Score = p2Score,
                    p1PocketedCount = whitePocketedTotal,
                    p2PocketedCount = blackPocketedTotal,
                    phase = TurnPhase.MATCH_OVER,
                    winner = PlayerSeat.PLAYER_1,
                    winReason = "${previousState.player1Name} cleared all White coins!",
                    statusBanner = "${previousState.player1Name} wins!"
                )
            }
            if (blackLeft == 0 && queenSettled && queenState != QueenState.NEEDS_COVER_P2) {
                return previousState.copy(
                    discs = updatedDiscs.toList(),
                    striker = createStrikerForTurn(PlayerSeat.PLAYER_2, updatedDiscs),
                    queenState = queenState,
                    p1Score = p1Score,
                    p2Score = p2Score,
                    p1PocketedCount = whitePocketedTotal,
                    p2PocketedCount = blackPocketedTotal,
                    phase = TurnPhase.MATCH_OVER,
                    winner = PlayerSeat.PLAYER_2,
                    winReason = "${previousState.player2Name} cleared all Black coins!",
                    statusBanner = "${previousState.player2Name} wins!"
                )
            }
        }

        val nextStriker = createStrikerForTurn(nextTurn, updatedDiscs)
        return previousState.copy(
            currentTurn = nextTurn,
            phase = TurnPhase.AIMING,
            discs = updatedDiscs.toList(),
            striker = nextStriker,
            queenState = queenState,
            p1Score = p1Score,
            p2Score = p2Score,
            p1PocketedCount = updatedDiscs.count { it.pocketed && it.type == DiscType.WHITE },
            p2PocketedCount = updatedDiscs.count { it.pocketed && it.type == DiscType.BLACK },
            statusBanner = banner,
            turnNumber = previousState.turnNumber + 1,
            strikerPlacementValid = isStrikerPositionValid(nextStriker.x, nextTurn, updatedDiscs),
            opponentAim = com.example.model.AimState()
        )
    }

    private fun returnDiscToCenter(discs: MutableList<DiscState>, type: DiscType): Boolean {
        val idx = discs.indexOfFirst { it.pocketed && it.type == type }
        if (idx == -1) return false

        val (cx, cy) = findFreeCenterSpot(discs)
        discs[idx] = discs[idx].copy(
            x = cx,
            y = cy,
            vx = 0f,
            vy = 0f,
            pocketed = false,
            sinkProgress = 0f
        )
        return true
    }

    private fun findFreeCenterSpot(discs: List<DiscState>): Pair<Float, Float> {
        val minSpacing = COIN_RADIUS * 2.15f
        val candidates = mutableListOf(500f to 500f)
        for (ring in 1..4) {
            val r = ring * minSpacing
            for (k in 0 until 8 * ring) {
                val a = (2.0 * PI * k) / (8 * ring)
                candidates += (500f + (r * cos(a)).toFloat()) to (500f + (r * sin(a)).toFloat())
            }
        }
        for ((cx, cy) in candidates) {
            val blocked = discs.any { !it.pocketed && hypot(it.x - cx, it.y - cy) < minSpacing }
            if (!blocked) return cx to cy
        }
        return 500f to 500f
    }

    fun predictAimRay(
        strikerX: Float,
        strikerY: Float,
        pullDx: Float,
        pullDy: Float,
        discs: List<DiscState>
    ): AimPrediction? {
        val pullLen = hypot(pullDx, pullDy)
        if (pullLen < MIN_PULL_DISTANCE) return null

        val dirX = -pullDx / pullLen
        val dirY = -pullDy / pullLen

        var closestT = Float.MAX_VALUE
        var hitCoin: DiscState? = null

        val combinedR = STRIKER_RADIUS + COIN_RADIUS
        for (d in discs) {
            if (d.pocketed) continue
            val ocX = strikerX - d.x
            val ocY = strikerY - d.y
            val b = ocX * dirX + ocY * dirY
            val c = (ocX * ocX + ocY * ocY) - combinedR * combinedR
            val disc = b * b - c
            if (disc >= 0f) {
                val t = -b - sqrt(disc)
                if (t > 0f && t < closestT) {
                    closestT = t
                    hitCoin = d
                }
            }
        }

        // Also clamp against cushion walls
        val minCoord = PLAY_MIN + STRIKER_RADIUS
        val maxCoord = PLAY_MAX - STRIKER_RADIUS
        val wallT = listOfNotNull(
            if (dirX < -0.001f) (minCoord - strikerX) / dirX else null,
            if (dirX > 0.001f) (maxCoord - strikerX) / dirX else null,
            if (dirY < -0.001f) (minCoord - strikerY) / dirY else null,
            if (dirY > 0.001f) (maxCoord - strikerY) / dirY else null
        ).filter { it > 0f }.minOrNull() ?: 900f

        if (hitCoin != null && closestT < wallT) {
            val hx = strikerX + dirX * closestT
            val hy = strikerY + dirY * closestT
            val dx = hitCoin.x - hx
            val dy = hitCoin.y - hy
            val len = hypot(dx, dy).coerceAtLeast(0.001f)
            return AimPrediction(
                hitX = hx,
                hitY = hy,
                hitCoinId = hitCoin.id,
                targetDeflectX = dx / len,
                targetDeflectY = dy / len
            )
        }

        val endT = min(wallT, 650f)
        return AimPrediction(
            hitX = strikerX + dirX * endT,
            hitY = strikerY + dirY * endT,
            hitCoinId = null
        )
    }

    fun computeShotVelocity(pullDx: Float, pullDy: Float): Pair<Float, Float>? {
        val pullDist = hypot(pullDx, pullDy)
        if (pullDist < MIN_PULL_DISTANCE) return null
        val power = ((pullDist - MIN_PULL_DISTANCE) / (MAX_PULL_DISTANCE - MIN_PULL_DISTANCE)).coerceIn(0.08f, 1f)
        val speed = power * MAX_SHOT_SPEED
        val dirX = -pullDx / pullDist
        val dirY = -pullDy / pullDist
        return (dirX * speed) to (dirY * speed)
    }

    /**
     * Smart AI shot planner for Player 2 (top baseline y = 165f)
     */
    fun computeAiShot(state: MatchState): Triple<Float, Float, Float> {
        val y = BASELINE_P2_Y
        val activeDiscs = state.discs.filter { !it.pocketed }
        val targetTypes = when (state.mode) {
            GameMode.POINTS_29 -> setOf(DiscType.QUEEN, DiscType.WHITE, DiscType.BLACK)
            GameMode.DISC_POOL -> setOf(DiscType.BLACK)
            GameMode.CLASSIC_QUEEN -> {
                val blackLeft = activeDiscs.count { it.type == DiscType.BLACK }
                when {
                    state.queenState == QueenState.NEEDS_COVER_P2 -> setOf(DiscType.BLACK)
                    blackLeft <= 4 && activeDiscs.any { it.type == DiscType.QUEEN } -> setOf(DiscType.QUEEN, DiscType.BLACK)
                    else -> setOf(DiscType.BLACK, DiscType.QUEEN)
                }
            }
        }

        val candidateTargets = activeDiscs.filter { it.type in targetTypes }
        var bestScore = Float.NEGATIVE_INFINITY
        var bestStrikerX = 500f
        var bestVx = 0f
        var bestVy = 1200f

        val strikerXs = (210..790 step 40).map { it.toFloat() }
        for (sx in strikerXs) {
            if (!isStrikerPositionValid(sx, PlayerSeat.PLAYER_2, activeDiscs)) continue
            for (target in candidateTargets) {
                for ((px, py) in POCKET_CENTERS) {
                    val toPocketX = px - target.x
                    val toPocketY = py - target.y
                    val distToPocket = hypot(toPocketX, toPocketY).coerceAtLeast(1f)
                    val dirPx = toPocketX / distToPocket
                    val dirPy = toPocketY / distToPocket

                    // Ghost ball point behind target coin
                    val ghostX = target.x - dirPx * (STRIKER_RADIUS + COIN_RADIUS)
                    val ghostY = target.y - dirPy * (STRIKER_RADIUS + COIN_RADIUS)

                    val toGhostX = ghostX - sx
                    val toGhostY = ghostY - y
                    val distToGhost = hypot(toGhostX, toGhostY).coerceAtLeast(1f)
                    val dirGx = toGhostX / distToGhost
                    val dirGy = toGhostY / distToGhost

                    // Alignment dot product (must hit forward toward pocket, not backward)
                    val cutDot = dirGx * dirPx + dirGy * dirPy
                    if (cutDot < 0.35f) continue

                    // Penalize obstructed path from striker to ghost and target to pocket
                    val pathBlocked = isPathBlocked(sx, y, ghostX, ghostY, activeDiscs, target.id, STRIKER_RADIUS + COIN_RADIUS - 3f)
                    val pocketBlocked = isPathBlocked(target.x, target.y, px, py, activeDiscs, target.id, COIN_RADIUS * 1.9f)

                    var score = cutDot * 120f - distToPocket * 0.06f - distToGhost * 0.03f
                    if (target.type == DiscType.QUEEN) score += 25f
                    if (pathBlocked) score -= 140f
                    if (pocketBlocked) score -= 95f

                    if (score > bestScore) {
                        bestScore = score
                        bestStrikerX = sx
                        val shotSpeed = (1250f + distToPocket * 0.7f + (1f - cutDot) * 450f)
                            .coerceIn(1150f, MAX_SHOT_SPEED * 0.92f)
                        // Small realistic human-like angle variance
                        val jitter = (Random.nextFloat() - 0.5f) * 0.045f
                        val c = cos(jitter)
                        val s = sin(jitter)
                        bestVx = (dirGx * c - dirGy * s) * shotSpeed
                        bestVy = (dirGx * s + dirGy * c) * shotSpeed
                    }
                }
            }
        }

        // If no good shot found (e.g., break shot), smash into center cluster
        if (bestScore < -20f) {
            bestStrikerX = findNearestValidStrikerX(500f + Random.nextInt(-90, 91), PlayerSeat.PLAYER_2, activeDiscs)
            val dx = 500f - bestStrikerX + Random.nextInt(-30, 31)
            val dy = 500f - y
            val len = hypot(dx, dy).coerceAtLeast(1f)
            bestVx = (dx / len) * 1850f
            bestVy = (dy / len) * 1850f
        }

        return Triple(bestStrikerX, bestVx, bestVy)
    }

    private fun isPathBlocked(
        x1: Float,
        y1: Float,
        x2: Float,
        y2: Float,
        discs: List<DiscState>,
        ignoreId: Int,
        clearance: Float
    ): Boolean {
        val dx = x2 - x1
        val dy = y2 - y1
        val lenSq = dx * dx + dy * dy
        if (lenSq < 1f) return false
        for (d in discs) {
            if (d.pocketed || d.id == ignoreId) continue
            val t = (((d.x - x1) * dx + (d.y - y1) * dy) / lenSq)
            if (t <= 0.05f || t >= 0.95f) continue
            val projX = x1 + t * dx
            val projY = y1 + t * dy
            if (hypot(d.x - projX, d.y - projY) < clearance) {
                return true
            }
        }
        return false
    }
}
