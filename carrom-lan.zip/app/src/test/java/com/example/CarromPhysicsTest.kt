package com.example

import com.example.engine.CarromPhysics
import com.example.model.DiscType
import com.example.model.GameMode
import com.example.model.MatchState
import com.example.model.PlayerSeat
import com.example.model.QueenState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CarromPhysicsTest {

    @Test
    fun initialRackHasExpectedCoinCounts() {
        val classic = CarromPhysics.createInitialDiscs(GameMode.CLASSIC_QUEEN)
        assertEquals(19, classic.size)
        assertEquals(9, classic.count { it.type == DiscType.WHITE })
        assertEquals(9, classic.count { it.type == DiscType.BLACK })
        assertEquals(1, classic.count { it.type == DiscType.QUEEN })

        val discPool = CarromPhysics.createInitialDiscs(GameMode.DISC_POOL)
        assertEquals(18, discPool.size)
        assertEquals(9, discPool.count { it.type == DiscType.WHITE })
        assertEquals(9, discPool.count { it.type == DiscType.BLACK })
        assertEquals(0, discPool.count { it.type == DiscType.QUEEN })
    }

    @Test
    fun queenCoverAndFoulRulesWorkCorrectly() {
        val discs = CarromPhysics.createInitialDiscs(GameMode.CLASSIC_QUEEN).toMutableList()
        // Mark Queen as pocketed
        val qIdx = discs.indexOfFirst { it.type == DiscType.QUEEN }
        discs[qIdx] = discs[qIdx].copy(pocketed = true, sinkProgress = 1f)

        val initialState = MatchState(
            mode = GameMode.CLASSIC_QUEEN,
            currentTurn = PlayerSeat.PLAYER_1,
            discs = discs,
            queenState = QueenState.ON_BOARD
        )

        // Pot Queen alone -> needs cover and keeps turn
        val afterQueenOnly = CarromPhysics.evaluateTurnResult(
            previousState = initialState,
            updatedDiscs = discs.toMutableList(),
            pocketedThisTurn = listOf(DiscType.QUEEN)
        )
        assertEquals(QueenState.NEEDS_COVER_P1, afterQueenOnly.queenState)
        assertEquals(PlayerSeat.PLAYER_1, afterQueenOnly.currentTurn)

        // Pot White coin on next turn -> Queen becomes COVERED_P1
        val discs2 = afterQueenOnly.discs.toMutableList()
        val wIdx = discs2.indexOfFirst { it.type == DiscType.WHITE }
        discs2[wIdx] = discs2[wIdx].copy(pocketed = true, sinkProgress = 1f)
        val afterCover = CarromPhysics.evaluateTurnResult(
            previousState = afterQueenOnly,
            updatedDiscs = discs2,
            pocketedThisTurn = listOf(DiscType.WHITE)
        )
        assertEquals(QueenState.COVERED_P1, afterCover.queenState)
        assertEquals(PlayerSeat.PLAYER_1, afterCover.currentTurn)
        assertEquals(4, afterCover.p1Score) // 1 white + 3 queen bonus

        // Striker foul returns a white coin to the board and passes turn
        val afterFoul = CarromPhysics.evaluateTurnResult(
            previousState = afterCover,
            updatedDiscs = afterCover.discs.toMutableList(),
            pocketedThisTurn = listOf(DiscType.STRIKER)
        )
        assertEquals(PlayerSeat.PLAYER_2, afterFoul.currentTurn)
        assertEquals(0, afterFoul.p1PocketedCount)
        assertFalse(afterFoul.discs[wIdx].pocketed)
    }

    @Test
    fun physicsSubstepTransfersMomentumAndPocketsCoins() {
        val discs = CarromPhysics.createInitialDiscs(GameMode.CLASSIC_QUEEN).toMutableList()
        val striker = CarromPhysics.createStrikerForTurn(PlayerSeat.PLAYER_1, discs)
            .copy(vx = 0f, vy = -1800f)

        var currentStriker = striker
        var maxImpact = 0f
        repeat(60) {
            val (nextStriker, events) = CarromPhysics.stepPhysics(0.016f, discs, currentStriker)
            currentStriker = nextStriker
            if (events.maxCoinImpact > maxImpact) maxImpact = events.maxCoinImpact
        }

        assertTrue("Break shot should hit the rack", maxImpact > 0.2f)
        val movedCoins = discs.count { it.x != 500f || it.y != 500f }
        assertTrue(movedCoins > 5)

        val aiState = MatchState(
            mode = GameMode.CLASSIC_QUEEN,
            currentTurn = PlayerSeat.PLAYER_2,
            discs = discs
        )
        val (sx, vx, vy) = CarromPhysics.computeAiShot(aiState)
        assertTrue(sx in CarromPhysics.BASELINE_MIN_X..CarromPhysics.BASELINE_MAX_X)
        assertNotNull(vx)
        assertNotNull(vy)
    }
}
